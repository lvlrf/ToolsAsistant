#!/bin/bash
# Dashboard installer
echo "Installing Dr.DNSttFucked Dashboard..."
pip3 install flask pyopenssl --break-system-packages
chmod +x dashboard/Dr.DNSttFucked.py
cp dashboard/Dr.DNSttFucked.py /usr/local/bin/
cat > /etc/systemd/system/dashboard.service << 'SVCEOF'
[Unit]
Description=Dr.DNSttFucked Dashboard
After=network.target

[Service]
Type=simple
User=root
ExecStart=/usr/bin/python3 /usr/local/bin/Dr.DNSttFucked.py
WorkingDirectory=/usr/local/bin
Restart=always

[Install]
WantedBy=multi-user.target
SVCEOF
systemctl daemon-reload
systemctl enable dashboard
systemctl start dashboard
echo "Dashboard installed! Access: https://YOUR_IP:8443"
echo "Username: admin"
echo "Password: check /etc/slipstream/dashboard-password.txt"
