#!/usr/bin/env python3
"""
Dr.DNSttFucked Dashboard
Web-based management dashboard for DNS Tunnel

توسعه: DrConnect
"""

from flask import Flask, render_template, jsonify, request, send_from_directory
from functools import wraps
import json
import os
import subprocess
import time
from datetime import datetime
from pathlib import Path

app = Flask(__name__)

# Configuration
CONFIG_FILE = "/etc/slipstream/pool-config.json"
DASHBOARD_PASSWORD_FILE = "/etc/slipstream/dashboard-password.txt"

# Load config
def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)
    return {}

config = load_config()

# ==================== Authentication ====================

def check_auth():
    """Simple authentication check"""
    auth = request.authorization
    if not auth:
        return False
    
    # Load password
    if os.path.exists(DASHBOARD_PASSWORD_FILE):
        with open(DASHBOARD_PASSWORD_FILE, 'r') as f:
            correct_password = f.read().strip()
    else:
        correct_password = "admin123"  # default
    
    return auth.username == "admin" and auth.password == correct_password

def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not check_auth():
            return ('Unauthorized', 401, {
                'WWW-Authenticate': 'Basic realm="Dr.DNSttFucked"'
            })
        return f(*args, **kwargs)
    return decorated

# ==================== Routes ====================

@app.route('/')
@requires_auth
def index():
    return render_template('index.html')

@app.route('/api/stats')
@requires_auth
def get_stats():
    """Get current statistics"""
    try:
        paths = config.get('paths', {})
        
        # Pool statistics
        pool_all_count = len(load_file_lines(paths.get('pool_all', '')))
        pool_active_count = len(load_file_lines(paths.get('pool_active', '')))
        pool_used_count = len(load_file_lines(paths.get('pool_used', '')))
        pool_failed_count = len(load_file_lines(paths.get('pool_failed', '')))
        
        # Rotation state
        rotation_state = load_json(paths.get('rotation_state', ''))
        
        # Traffic statistics
        traffic_stats = get_traffic_stats()
        
        # Service status
        services = {
            'slipstream-client': is_service_running('slipstream-client'),
            'dns-pool-manager': is_service_running('dns-pool-manager'),
            'backhaul-server': is_service_running('backhaul-server')
        }
        
        # Bandwidth prediction
        predicted_mbps = pool_active_count * 5
        
        return jsonify({
            'pool': {
                'total': pool_all_count,
                'active': pool_active_count,
                'used': pool_used_count,
                'failed': pool_failed_count
            },
            'rotation': rotation_state,
            'traffic': traffic_stats,
            'services': services,
            'prediction': {
                'mbps': predicted_mbps,
                'formula': f'{pool_active_count} × 5 Mbps'
            }
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/service/<service>/<action>', methods=['POST'])
@requires_auth
def service_action(service, action):
    """Control services"""
    allowed_services = ['slipstream-client', 'dns-pool-manager', 'backhaul-server']
    allowed_actions = ['start', 'stop', 'restart']
    
    if service not in allowed_services or action not in allowed_actions:
        return jsonify({'error': 'Invalid service or action'}), 400
    
    try:
        subprocess.run(['systemctl', action, service], check=True)
        return jsonify({'status': 'success', 'message': f'{service} {action}ed'})
    except subprocess.CalledProcessError as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/iperf3/test', methods=['POST'])
@requires_auth
def run_iperf3():
    """Run iperf3 test"""
    try:
        iperf_config = config.get('iperf3', {})
        server = iperf_config.get('server', 'iperf.he.net')
        port = iperf_config.get('port', 5201)
        duration = iperf_config.get('duration', 10)
        
        # Upload test
        upload_cmd = ['iperf3', '-c', server, '-p', str(port), '-t', str(duration), '-J']
        upload_result = subprocess.run(upload_cmd, capture_output=True, text=True, timeout=duration + 10)
        upload_data = json.loads(upload_result.stdout)
        upload_mbps = upload_data['end']['sum_sent']['bits_per_second'] / 1_000_000
        
        time.sleep(2)
        
        # Download test
        download_cmd = ['iperf3', '-c', server, '-p', str(port), '-t', str(duration), '-R', '-J']
        download_result = subprocess.run(download_cmd, capture_output=True, text=True, timeout=duration + 10)
        download_data = json.loads(download_result.stdout)
        download_mbps = download_data['end']['sum_received']['bits_per_second'] / 1_000_000
        
        # Save result
        result_file = "/var/log/iperf3-results.log"
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        with open(result_file, 'a') as f:
            f.write(f"{timestamp} | Upload: {upload_mbps:.2f} Mbps | Download: {download_mbps:.2f} Mbps\n")
        
        return jsonify({
            'upload': round(upload_mbps, 2),
            'download': round(download_mbps, 2),
            'timestamp': timestamp
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/settings', methods=['GET', 'POST'])
@requires_auth
def settings():
    """Get or update settings"""
    if request.method == 'GET':
        return jsonify(config.get('pool_settings', {}))
    
    elif request.method == 'POST':
        try:
            new_settings = request.json
            config['pool_settings'].update(new_settings)
            
            # Save config
            with open(CONFIG_FILE, 'w') as f:
                json.dump(config, f, indent=2)
            
            # Restart pool manager to apply
            subprocess.run(['systemctl', 'restart', 'dns-pool-manager'], check=True)
            
            return jsonify({'status': 'success', 'message': 'Settings updated'})
        except Exception as e:
            return jsonify({'error': str(e)}), 500

@app.route('/api/force-rotation', methods=['POST'])
@requires_auth
def force_rotation():
    """Force immediate rotation"""
    try:
        subprocess.run(['systemctl', 'restart', 'dns-pool-manager'], check=True)
        return jsonify({'status': 'success', 'message': 'Rotation triggered'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ==================== Helper Functions ====================

def load_file_lines(filepath):
    if not filepath or not os.path.exists(filepath):
        return []
    with open(filepath, 'r') as f:
        return [line.strip() for line in f if line.strip()]

def load_json(filepath):
    if not filepath or not os.path.exists(filepath):
        return {}
    try:
        with open(filepath, 'r') as f:
            return json.load(f)
    except:
        return {}

def is_service_running(service):
    try:
        result = subprocess.run(
            ['systemctl', 'is-active', service],
            capture_output=True,
            text=True
        )
        return result.stdout.strip() == 'active'
    except:
        return False

def get_traffic_stats():
    """Get traffic statistics from network interface"""
    try:
        # Find main interface
        result = subprocess.run(['ip', 'route'], capture_output=True, text=True)
        for line in result.stdout.split('\n'):
            if 'default' in line:
                iface = line.split()[4]
                break
        else:
            iface = 'eth0'
        
        # Read stats
        rx_bytes = int(Path(f'/sys/class/net/{iface}/statistics/rx_bytes').read_text().strip())
        tx_bytes = int(Path(f'/sys/class/net/{iface}/statistics/tx_bytes').read_text().strip())
        
        return {
            'interface': iface,
            'rx_mb': round(rx_bytes / 1048576, 2),
            'tx_mb': round(tx_bytes / 1048576, 2),
            'total_mb': round((rx_bytes + tx_bytes) / 1048576, 2)
        }
    except:
        return {
            'interface': 'unknown',
            'rx_mb': 0,
            'tx_mb': 0,
            'total_mb': 0
        }

# ==================== Main ====================

if __name__ == '__main__':
    # Create password file if not exists
    if not os.path.exists(DASHBOARD_PASSWORD_FILE):
        import secrets
        password = secrets.token_urlsafe(12)
        os.makedirs(os.path.dirname(DASHBOARD_PASSWORD_FILE), exist_ok=True)
        with open(DASHBOARD_PASSWORD_FILE, 'w') as f:
            f.write(password)
        print(f"Generated password: {password}")
        print(f"Saved to: {DASHBOARD_PASSWORD_FILE}")
    
    # Run server
    app.run(
        host='0.0.0.0',
        port=8443,
        debug=False,
        ssl_context='adhoc'  # Self-signed cert
    )
