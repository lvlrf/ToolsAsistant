#!/bin/bash

# setup-dns.sh
# راهنمای تنظیم DNS records
# توسعه: DrConnect

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}"
echo "═══════════════════════════════════════════════"
echo "  DNS Setup Guide"
echo "  Interactive DNS Configuration Helper"
echo "═══════════════════════════════════════════════"
echo -e "${NC}"
echo ""

# Input
read -p "Enter your main domain (e.g., irihost.com): " MAIN_DOMAIN
read -p "Enter tunnel subdomain (e.g., t): " TUNNEL_SUB
read -p "Enter foreign server IP: " SERVER_IP

TUNNEL_DOMAIN="${TUNNEL_SUB}.${MAIN_DOMAIN}"
NS_DOMAIN="ns1.${MAIN_DOMAIN}"
TEST_DOMAIN="test.${TUNNEL_DOMAIN}"

echo ""
echo -e "${GREEN}═══════════════════════════════════════════════${NC}"
echo -e "${GREEN}DNS Records Configuration${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════${NC}"
echo ""

echo -e "${YELLOW}Step 1: Add A Record${NC}"
echo "  Type:  A"
echo "  Name:  ns1"
echo "  Value: $SERVER_IP"
echo "  TTL:   300 (or Auto)"
echo ""

echo -e "${YELLOW}Step 2: Add NS Record for Tunnel${NC}"
echo "  Type:  NS"
echo "  Name:  $TUNNEL_SUB"
echo "  Value: $NS_DOMAIN"
echo "  TTL:   300 (or Auto)"
echo ""

echo -e "${YELLOW}Step 3: Add NS Record for Test (Optional)${NC}"
echo "  Type:  NS"
echo "  Name:  test.$TUNNEL_SUB"
echo "  Value: $NS_DOMAIN"
echo "  TTL:   300 (or Auto)"
echo ""

echo -e "${BLUE}═══════════════════════════════════════════════${NC}"
echo -e "${BLUE}Provider-Specific Instructions${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════${NC}"
echo ""

echo -e "${GREEN}Cloudflare:${NC}"
echo "  1. Go to DNS management"
echo "  2. Add records above"
echo "  3. IMPORTANT: Turn OFF proxy (grey cloud) for NS records"
echo ""

echo -e "${GREEN}Namecheap:${NC}"
echo "  1. Advanced DNS → Add records"
echo "  2. A Record: Host=ns1, Value=$SERVER_IP"
echo "  3. NS Record: Host=$TUNNEL_SUB, Value=$NS_DOMAIN"
echo ""

echo -e "${GREEN}GoDaddy:${NC}"
echo "  1. DNS Management → Add records"
echo "  2. Follow the same pattern as above"
echo ""

echo -e "${BLUE}═══════════════════════════════════════════════${NC}"
echo -e "${BLUE}Testing DNS Propagation${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════${NC}"
echo ""

echo "Wait 5-10 minutes, then test:"
echo ""
echo "  dig @8.8.8.8 $NS_DOMAIN"
echo "  dig @8.8.8.8 $TUNNEL_DOMAIN NS"
echo ""

read -p "Test DNS now? (y/n): " TEST_NOW

if [ "$TEST_NOW" = "y" ] || [ "$TEST_NOW" = "Y" ]; then
    echo ""
    echo -e "${GREEN}[TEST]${NC} Testing A record..."
    dig @8.8.8.8 $NS_DOMAIN +short
    
    echo ""
    echo -e "${GREEN}[TEST]${NC} Testing NS record..."
    dig @8.8.8.8 $TUNNEL_DOMAIN NS +short
    
    echo ""
    echo -e "${YELLOW}[INFO]${NC} If empty, wait a few minutes and try again"
fi

echo ""
echo -e "${GREEN}DNS setup guide completed!${NC}"
echo ""
