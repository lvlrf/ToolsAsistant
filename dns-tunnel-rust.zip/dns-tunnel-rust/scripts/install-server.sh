#!/bin/bash

# install-server.sh
# نصب خودکار slipstream-rust DNS Tunnel Server (سرور خارج)
# توسعه: DrConnect

set -e

# ==================== Colors ====================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# ==================== Functions ====================

print_header() {
    echo -e "${BLUE}"
    echo "═══════════════════════════════════════════════"
    echo "  DNS Tunnel Server Installer"
    echo "  slipstream-rust - Foreign Server"
    echo "═══════════════════════════════════════════════"
    echo -e "${NC}"
}

print_step() {
    echo -e "${GREEN}[STEP]${NC} $1"
}

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_root() {
    if [ "$EUID" -ne 0 ]; then 
        print_error "Please run as root"
        exit 1
    fi
}

# ==================== Main Installation ====================

print_header

check_root

# 1. نصب dependencies
print_step "Installing dependencies..."
apt update
apt install -y \
    build-essential \
    rustc \
    cargo \
    cmake \
    pkg-config \
    libssl-dev \
    python3 \
    python3-pip \
    git \
    curl \
    wget \
    ufw \
    iperf3 \
    dnsutils \
    net-tools

print_info "Dependencies installed ✓"

# 2. Clone slipstream-rust
print_step "Cloning slipstream-rust..."
cd /tmp
if [ -d "slipstream-rust" ]; then
    rm -rf slipstream-rust
fi

git clone https://github.com/Mygod/slipstream-rust.git
cd slipstream-rust

# 3. Initialize submodules
print_step "Initializing submodules..."
git submodule update --init --recursive

# 4. Build slipstream-server
print_step "Building slipstream-server (this may take 10-15 minutes)..."
cargo build --release -p slipstream-server

# 5. Install binary
print_step "Installing binary..."
cp target/release/slipstream-server /usr/local/bin/
chmod +x /usr/local/bin/slipstream-server

print_info "Binary installed at /usr/local/bin/slipstream-server ✓"

# 6. Create directories
print_step "Creating directories..."
mkdir -p /etc/slipstream
mkdir -p /etc/backhaul

# 7. Generate TLS certificate
print_step "Generating TLS certificate..."

read -p "Enter your domain (e.g., t.irihost.com): " DOMAIN

openssl req -x509 -newkey rsa:2048 -nodes \
    -keyout /etc/slipstream/key.pem \
    -out /etc/slipstream/cert.pem \
    -days 365 \
    -subj "/CN=$DOMAIN"

chmod 600 /etc/slipstream/key.pem
chmod 644 /etc/slipstream/cert.pem

print_info "Certificate generated ✓"
print_info "  Cert: /etc/slipstream/cert.pem"
print_info "  Key:  /etc/slipstream/key.pem"

# 8. Install systemd service
print_step "Installing systemd service..."

# اگه از فولدر پروژه اجرا میشه
if [ -f "../configs/slipstream-server.service" ]; then
    cp ../configs/slipstream-server.service /etc/systemd/system/
else
    # ساخت دستی
    cat > /etc/systemd/system/slipstream-server.service <<EOF
[Unit]
Description=slipstream-rust DNS Tunnel Server
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
ExecStart=/usr/local/bin/slipstream-server \\
  --dns-listen-port 53 \\
  --target-address 127.0.0.1:5000 \\
  --domain $DOMAIN \\
  --cert /etc/slipstream/cert.pem \\
  --key /etc/slipstream/key.pem \\
  --authoritative

WorkingDirectory=/etc/slipstream
Restart=always
RestartSec=5
LimitNOFILE=1048576
AmbientCapabilities=CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF
fi

systemctl daemon-reload
systemctl enable slipstream-server

print_info "Service installed ✓"

# 9. Kernel tuning
print_step "Applying kernel optimizations..."

if [ -f "../configs/99-tunnel-tuning.conf" ]; then
    cp ../configs/99-tunnel-tuning.conf /etc/sysctl.d/
else
    # کپی از template
    print_warn "99-tunnel-tuning.conf not found, skipping..."
fi

# Load BBR module
modprobe tcp_bbr 2>/dev/null || true
echo "tcp_bbr" >> /etc/modules-load.d/bbr.conf

# Apply sysctl
sysctl -p /etc/sysctl.d/99-tunnel-tuning.conf 2>/dev/null || true

print_info "Kernel optimizations applied ✓"

# 10. Firewall
print_step "Configuring firewall..."

ufw allow 53/udp comment "DNS Tunnel"
ufw allow 22/tcp comment "SSH"

# Backhaul port (نمونه)
read -p "Enter Backhaul port (or Enter to skip): " BACKHAUL_PORT
if [ ! -z "$BACKHAUL_PORT" ]; then
    ufw allow $BACKHAUL_PORT/tcp comment "Backhaul"
fi

print_info "Firewall configured ✓"

# 11. Final summary
print_step "Installation completed!"

echo ""
echo -e "${GREEN}══════════════════════════════════════════════════${NC}"
echo -e "${GREEN}Installation Summary:${NC}"
echo -e "${GREEN}══════════════════════════════════════════════════${NC}"
echo ""
echo "Binary:    /usr/local/bin/slipstream-server"
echo "Config:    /etc/slipstream/"
echo "Cert:      /etc/slipstream/cert.pem"
echo "Key:       /etc/slipstream/key.pem"
echo "Domain:    $DOMAIN"
echo ""
echo -e "${YELLOW}Next steps:${NC}"
echo ""
echo "1. Setup DNS records:"
echo "   A:  ns1.yourdomain.com → YOUR_SERVER_IP"
echo "   NS: $DOMAIN → ns1.yourdomain.com"
echo ""
echo "2. Install Backhaul (optional):"
echo "   wget https://github.com/Musixal/Backhaul/releases/latest/download/backhaul_linux_amd64.tar.gz"
echo "   tar -xzf backhaul_linux_amd64.tar.gz"
echo "   mv backhaul /usr/local/bin/"
echo ""
echo "3. Start server:"
echo "   systemctl start slipstream-server"
echo "   systemctl status slipstream-server"
echo ""
echo "4. Check logs:"
echo "   journalctl -fu slipstream-server"
echo ""
echo -e "${GREEN}══════════════════════════════════════════════════${NC}"
echo ""

read -p "Start slipstream-server now? (y/n): " START_NOW
if [ "$START_NOW" = "y" ] || [ "$START_NOW" = "Y" ]; then
    systemctl start slipstream-server
    sleep 2
    systemctl status slipstream-server
fi

print_info "Installation script completed successfully! ✓"
