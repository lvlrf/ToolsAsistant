#!/bin/bash

# install-client.sh
# نصب خودکار slipstream-rust DNS Tunnel Client (سرور ایران)
# توسعه: DrConnect

set -e

# ==================== Colors ====================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# ==================== Functions ====================

print_header() {
    echo -e "${BLUE}"
    echo "═══════════════════════════════════════════════"
    echo "  DNS Tunnel Client Installer"
    echo "  slipstream-rust - Iran Server"
    echo "═══════════════════════════════════════════════"
    echo -e "${NC}"
}

print_step() {
    echo -e "${GREEN}[STEP]${NC} $1"
}

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_root() {
    if [ "$EUID" -ne 0 ]; then 
        print_error "Please run as root"
        exit 1
    fi
}

# ==================== Main Installation ====================

print_header

check_root

# 1. نصب dependencies
print_step "Installing dependencies..."
apt update
apt install -y \
    build-essential \
    rustc \
    cargo \
    cmake \
    pkg-config \
    libssl-dev \
    python3 \
    python3-pip \
    git \
    curl \
    wget \
    ufw \
    iperf3 \
    dnsutils \
    net-tools \
    jq

print_info "Dependencies installed ✓"

# 2. Clone slipstream-rust
print_step "Cloning slipstream-rust..."
cd /tmp
if [ -d "slipstream-rust" ]; then
    rm -rf slipstream-rust
fi

git clone https://github.com/Mygod/slipstream-rust.git
cd slipstream-rust

# 3. Initialize submodules
print_step "Initializing submodules..."
git submodule update --init --recursive

# 4. Build slipstream-client
print_step "Building slipstream-client (this may take 10-15 minutes)..."
cargo build --release -p slipstream-client

# 5. Install binary
print_step "Installing binary..."
cp target/release/slipstream-client /usr/local/bin/
chmod +x /usr/local/bin/slipstream-client

print_info "Binary installed at /usr/local/bin/slipstream-client ✓"

# 6. Create directories
print_step "Creating directories..."
mkdir -p /etc/slipstream
mkdir -p /etc/slipstream/dns-pool
mkdir -p /etc/backhaul
mkdir -p /var/log

# 7. Initialize pool files
print_step "Initializing DNS pool files..."

touch /etc/slipstream/dns-pool/pool-all.txt
touch /etc/slipstream/dns-pool/pool-active.txt
touch /etc/slipstream/dns-pool/pool-used.txt
touch /etc/slipstream/dns-pool/pool-failed.txt
echo '{}' > /etc/slipstream/dns-pool/rotation-state.json
echo '{}' > /etc/slipstream/dns-pool/stats-history.json

print_warn "IMPORTANT: You must upload your DNS resolver list to:"
print_warn "  /etc/slipstream/dns-pool/pool-all.txt"
print_warn "Format: One IP per line (e.g., 1.2.3.4)"

# 8. Install pool-config.json
print_step "Installing pool configuration..."

read -p "Enter tunnel domain (e.g., t.irihost.com): " DOMAIN

if [ -f "../configs/pool-config.json" ]; then
    cp ../configs/pool-config.json /etc/slipstream/
else
    cat > /etc/slipstream/pool-config.json <<'EOF'
{
  "pool_settings": {
    "active_pool_size": 100,
    "rotation_interval": 3600,
    "test_batch_size": 20,
    "max_rtt_threshold": 2000
  },
  "test_server": {
    "domain": "test.DOMAIN_PLACEHOLDER",
    "port": 5353,
    "timeout": 3
  },
  "iperf3": {
    "server": "iperf.he.net",
    "port": 5201,
    "duration": 10
  }
}
EOF
    sed -i "s/DOMAIN_PLACEHOLDER/$DOMAIN/g" /etc/slipstream/pool-config.json
fi

print_info "Configuration installed ✓"

# 9. Install dns-pool-manager.py
print_step "Installing DNS pool manager..."

if [ -f "../scripts/dns-pool-manager.py" ]; then
    cp ../scripts/dns-pool-manager.py /usr/local/bin/
    chmod +x /usr/local/bin/dns-pool-manager.py
else
    print_warn "dns-pool-manager.py not found, you'll need to copy it manually"
fi

# 10. Install systemd services
print_step "Installing systemd services..."

# slipstream-client service
if [ -f "../configs/slipstream-client.service" ]; then
    cp ../configs/slipstream-client.service /etc/systemd/system/
else
    cat > /etc/systemd/system/slipstream-client.service <<EOF
[Unit]
Description=slipstream-rust DNS Tunnel Client
After=network-online.target dns-pool-manager.service
Requires=dns-pool-manager.service

[Service]
Type=simple
User=root
ExecStart=/usr/local/bin/slipstream-client \\
  --tcp-listen-port 8080 \\
  --resolvers-file /etc/slipstream/dns-pool/pool-active.txt \\
  --domain $DOMAIN

ExecReload=/bin/kill -HUP \$MAINPID
WorkingDirectory=/etc/slipstream
Restart=always
RestartSec=5
LimitNOFILE=1048576
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF
fi

# dns-pool-manager service
if [ -f "../configs/dns-pool-manager.service" ]; then
    cp ../configs/dns-pool-manager.service /etc/systemd/system/
else
    cat > /etc/systemd/system/dns-pool-manager.service <<EOF
[Unit]
Description=DNS Resolver Pool Manager
After=network-online.target
Before=slipstream-client.service

[Service]
Type=simple
User=root
ExecStart=/usr/bin/python3 /usr/local/bin/dns-pool-manager.py --config /etc/slipstream/pool-config.json
WorkingDirectory=/etc/slipstream/dns-pool
Restart=always
RestartSec=10
LimitNOFILE=65536
StandardOutput=journal
StandardError=journal
Environment="PYTHONUNBUFFERED=1"

[Install]
WantedBy=multi-user.target
EOF
fi

systemctl daemon-reload
systemctl enable slipstream-client
systemctl enable dns-pool-manager

print_info "Services installed ✓"

# 11. Kernel tuning
print_step "Applying kernel optimizations..."

if [ -f "../configs/99-tunnel-tuning.conf" ]; then
    cp ../configs/99-tunnel-tuning.conf /etc/sysctl.d/
fi

modprobe tcp_bbr 2>/dev/null || true
echo "tcp_bbr" >> /etc/modules-load.d/bbr.conf

sysctl -p /etc/sysctl.d/99-tunnel-tuning.conf 2>/dev/null || true

print_info "Kernel optimizations applied ✓"

# 12. Final summary
print_step "Installation completed!"

echo ""
echo -e "${GREEN}══════════════════════════════════════════════════${NC}"
echo -e "${GREEN}Installation Summary:${NC}"
echo -e "${GREEN}══════════════════════════════════════════════════${NC}"
echo ""
echo "Binary:        /usr/local/bin/slipstream-client"
echo "Config:        /etc/slipstream/"
echo "Pool Manager:  /usr/local/bin/dns-pool-manager.py"
echo "Pool Dir:      /etc/slipstream/dns-pool/"
echo "Domain:        $DOMAIN"
echo ""
echo -e "${YELLOW}CRITICAL - Next steps:${NC}"
echo ""
echo "1. Upload DNS resolver list:"
echo "   scp pool-all.txt root@THIS_SERVER:/etc/slipstream/dns-pool/pool-all.txt"
echo "   Format: One IP per line (no ports)"
echo ""
echo "2. Install Dashboard:"
echo "   cd dashboard/"
echo "   ./setup-dashboard.sh"
echo ""
echo "3. Install Backhaul (optional):"
echo "   wget https://github.com/Musixal/Backhaul/releases/latest/download/backhaul_linux_amd64.tar.gz"
echo "   tar -xzf backhaul_linux_amd64.tar.gz"
echo "   mv backhaul /usr/local/bin/"
echo ""
echo "4. Start services (AFTER uploading pool-all.txt):"
echo "   systemctl start dns-pool-manager"
echo "   systemctl start slipstream-client"
echo ""
echo "5. Monitor:"
echo "   journalctl -fu dns-pool-manager"
echo "   journalctl -fu slipstream-client"
echo ""
echo -e "${GREEN}══════════════════════════════════════════════════${NC}"
echo ""

print_warn "Remember: You MUST upload pool-all.txt before starting services!"

print_info "Installation script completed successfully! ✓"
