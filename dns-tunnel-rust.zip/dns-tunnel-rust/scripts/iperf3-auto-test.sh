#!/bin/bash

# iperf3-auto-test.sh
# تست خودکار bandwidth با iperf3
# توسعه: DrConnect

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Config
IPERF_SERVER="iperf.he.net"
IPERF_PORT=5201
DURATION=10

echo -e "${BLUE}═══════════════════════════════════════${NC}"
echo -e "${BLUE}  iperf3 Bandwidth Test${NC}"
echo -e "${BLUE}═══════════════════════════════════════${NC}"
echo ""

# بررسی iperf3
if ! command -v iperf3 &> /dev/null; then
    echo -e "${YELLOW}[ERROR]${NC} iperf3 not found"
    echo "Install: apt install iperf3"
    exit 1
fi

# Upload test
echo -e "${GREEN}[1/2]${NC} Testing upload speed..."
UPLOAD_RESULT=$(iperf3 -c $IPERF_SERVER -p $IPERF_PORT -t $DURATION -J 2>/dev/null)

if [ $? -eq 0 ]; then
    UPLOAD_MBPS=$(echo "$UPLOAD_RESULT" | jq -r '.end.sum_sent.bits_per_second' 2>/dev/null)
    UPLOAD_MBPS=$(awk "BEGIN {print $UPLOAD_MBPS / 1000000}")
    echo -e "  Upload: ${GREEN}${UPLOAD_MBPS} Mbps${NC}"
else
    echo -e "  Upload: ${YELLOW}Failed${NC}"
    UPLOAD_MBPS=0
fi

sleep 2

# Download test
echo -e "${GREEN}[2/2]${NC} Testing download speed..."
DOWNLOAD_RESULT=$(iperf3 -c $IPERF_SERVER -p $IPERF_PORT -t $DURATION -R -J 2>/dev/null)

if [ $? -eq 0 ]; then
    DOWNLOAD_MBPS=$(echo "$DOWNLOAD_RESULT" | jq -r '.end.sum_received.bits_per_second' 2>/dev/null)
    DOWNLOAD_MBPS=$(awk "BEGIN {print $DOWNLOAD_MBPS / 1000000}")
    echo -e "  Download: ${GREEN}${DOWNLOAD_MBPS} Mbps${NC}"
else
    echo -e "  Download: ${YELLOW}Failed${NC}"
    DOWNLOAD_MBPS=0
fi

# Summary
echo ""
echo -e "${BLUE}═══════════════════════════════════════${NC}"
echo -e "${GREEN}Results:${NC}"
echo -e "${BLUE}═══════════════════════════════════════${NC}"
echo ""
printf "  Upload:   %10.2f Mbps\n" $UPLOAD_MBPS
printf "  Download: %10.2f Mbps\n" $DOWNLOAD_MBPS
printf "  Total:    %10.2f Mbps\n" $(awk "BEGIN {print $UPLOAD_MBPS + $DOWNLOAD_MBPS}")
echo ""

# Save to file
RESULT_FILE="/var/log/iperf3-results.log"
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
echo "$TIMESTAMP | Upload: $UPLOAD_MBPS Mbps | Download: $DOWNLOAD_MBPS Mbps" >> $RESULT_FILE

echo "Results saved to: $RESULT_FILE"
echo ""

# Exit code based on success
if (( $(echo "$UPLOAD_MBPS > 0" | bc -l) )) && (( $(echo "$DOWNLOAD_MBPS > 0" | bc -l) )); then
    exit 0
else
    exit 1
fi
