#!/bin/bash

# troubleshoot.sh
# Automated troubleshooting script
# توسعه: DrConnect

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'

print_header() {
    echo -e "${BLUE}"
    echo "═══════════════════════════════════════════════"
    echo "  DNS Tunnel Troubleshooter"
    echo "═══════════════════════════════════════════════"
    echo -e "${NC}"
}

check_pass() {
    echo -e "  [${GREEN}✓${NC}] $1"
}

check_fail() {
    echo -e "  [${RED}✗${NC}] $1"
}

check_warn() {
    echo -e "  [${YELLOW}!${NC}] $1"
}

print_header

# 1. Check Services
echo ""
echo -e "${GREEN}[1/10] Checking Services...${NC}"
echo "─────────────────────────────────────────────────"

if systemctl is-active --quiet slipstream-client; then
    check_pass "slipstream-client is running"
else
    check_fail "slipstream-client is NOT running"
    echo "         Fix: systemctl start slipstream-client"
fi

if systemctl is-active --quiet dns-pool-manager; then
    check_pass "dns-pool-manager is running"
else
    check_fail "dns-pool-manager is NOT running"
    echo "         Fix: systemctl start dns-pool-manager"
fi

# 2. Check Binaries
echo ""
echo -e "${GREEN}[2/10] Checking Binaries...${NC}"
echo "─────────────────────────────────────────────────"

if [ -f "/usr/local/bin/slipstream-client" ]; then
    check_pass "slipstream-client binary exists"
else
    check_fail "slipstream-client binary NOT found"
    echo "         Fix: Run install-client.sh"
fi

if [ -f "/usr/local/bin/dns-pool-manager.py" ]; then
    check_pass "dns-pool-manager.py exists"
else
    check_fail "dns-pool-manager.py NOT found"
    echo "         Fix: Copy from scripts/ directory"
fi

# 3. Check Pool Files
echo ""
echo -e "${GREEN}[3/10] Checking Pool Files...${NC}"
echo "─────────────────────────────────────────────────"

if [ -f "/etc/slipstream/dns-pool/pool-all.txt" ]; then
    POOL_COUNT=$(wc -l < /etc/slipstream/dns-pool/pool-all.txt)
    if [ $POOL_COUNT -gt 0 ]; then
        check_pass "pool-all.txt exists ($POOL_COUNT IPs)"
    else
        check_warn "pool-all.txt is EMPTY"
        echo "         Fix: Upload DNS resolver list"
    fi
else
    check_fail "pool-all.txt NOT found"
    echo "         Fix: Create /etc/slipstream/dns-pool/pool-all.txt"
fi

if [ -f "/etc/slipstream/dns-pool/pool-active.txt" ]; then
    ACTIVE_COUNT=$(wc -l < /etc/slipstream/dns-pool/pool-active.txt)
    if [ $ACTIVE_COUNT -gt 0 ]; then
        check_pass "pool-active.txt has $ACTIVE_COUNT resolvers"
    else
        check_warn "pool-active.txt is empty (first rotation not done yet)"
    fi
else
    check_warn "pool-active.txt not found"
fi

# 4. Check Configuration
echo ""
echo -e "${GREEN}[4/10] Checking Configuration...${NC}"
echo "─────────────────────────────────────────────────"

if [ -f "/etc/slipstream/pool-config.json" ]; then
    check_pass "pool-config.json exists"
    
    # Validate JSON
    if jq empty /etc/slipstream/pool-config.json 2>/dev/null; then
        check_pass "pool-config.json is valid JSON"
    else
        check_fail "pool-config.json has INVALID JSON"
    fi
else
    check_fail "pool-config.json NOT found"
fi

# 5. Check Ports
echo ""
echo -e "${GREEN}[5/10] Checking Ports...${NC}"
echo "─────────────────────────────────────────────────"

if ss -tlnp | grep -q :8080; then
    check_pass "Port 8080 is listening (slipstream-client)"
else
    check_fail "Port 8080 is NOT listening"
    echo "         Fix: Check if slipstream-client is running"
fi

# 6. Check DNS Resolution
echo ""
echo -e "${GREEN}[6/10] Checking DNS Resolution...${NC}"
echo "─────────────────────────────────────────────────"

if dig @8.8.8.8 google.com +short > /dev/null 2>&1; then
    check_pass "DNS resolution works"
else
    check_fail "DNS resolution FAILED"
    echo "         Fix: Check internet connectivity"
fi

# 7. Check Kernel Tuning
echo ""
echo -e "${GREEN}[7/10] Checking Kernel Tuning...${NC}"
echo "─────────────────────────────────────────────────"

BBR=$(sysctl net.ipv4.tcp_congestion_control 2>/dev/null | awk '{print $3}')
if [ "$BBR" = "bbr" ]; then
    check_pass "BBR congestion control is enabled"
else
    check_warn "BBR is NOT enabled (current: $BBR)"
    echo "         Fix: modprobe tcp_bbr && sysctl -w net.ipv4.tcp_congestion_control=bbr"
fi

IP_FORWARD=$(sysctl net.ipv4.ip_forward 2>/dev/null | awk '{print $3}')
if [ "$IP_FORWARD" = "1" ]; then
    check_pass "IP forwarding is enabled"
else
    check_fail "IP forwarding is DISABLED"
    echo "         Fix: sysctl -w net.ipv4.ip_forward=1"
fi

# 8. Check Logs for Errors
echo ""
echo -e "${GREEN}[8/10] Checking Logs...${NC}"
echo "─────────────────────────────────────────────────"

ERROR_COUNT=$(journalctl -u slipstream-client --since "1 hour ago" | grep -ic "error" 2>/dev/null || echo "0")
if [ $ERROR_COUNT -eq 0 ]; then
    check_pass "No errors in slipstream-client logs (last hour)"
else
    check_warn "Found $ERROR_COUNT errors in logs"
    echo "         Check: journalctl -eu slipstream-client"
fi

# 9. Check System Resources
echo ""
echo -e "${GREEN}[9/10] Checking System Resources...${NC}"
echo "─────────────────────────────────────────────────"

MEM_AVAILABLE=$(free -m | awk 'NR==2{print $7}')
if [ $MEM_AVAILABLE -gt 500 ]; then
    check_pass "Sufficient memory available (${MEM_AVAILABLE}MB)"
else
    check_warn "Low memory available (${MEM_AVAILABLE}MB)"
fi

DISK_AVAILABLE=$(df -BM /etc/slipstream | awk 'NR==2{print $4}' | sed 's/M//')
if [ $DISK_AVAILABLE -gt 100 ]; then
    check_pass "Sufficient disk space (${DISK_AVAILABLE}MB)"
else
    check_warn "Low disk space (${DISK_AVAILABLE}MB)"
fi

# 10. Test iperf3
echo ""
echo -e "${GREEN}[10/10] Testing Bandwidth...${NC}"
echo "─────────────────────────────────────────────────"

if command -v iperf3 &> /dev/null; then
    check_pass "iperf3 is installed"
    
    read -p "Run bandwidth test now? (y/n): " RUN_TEST
    if [ "$RUN_TEST" = "y" ] || [ "$RUN_TEST" = "Y" ]; then
        echo ""
        echo "Running test..."
        bash /root/dns-tunnel-rust/scripts/iperf3-auto-test.sh 2>/dev/null || echo "Test failed"
    fi
else
    check_warn "iperf3 not installed"
    echo "         Install: apt install iperf3"
fi

# Summary
echo ""
echo -e "${BLUE}═══════════════════════════════════════════════${NC}"
echo -e "${BLUE}Troubleshooting Summary${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════${NC}"
echo ""
echo "Common issues and fixes:"
echo ""
echo "1. Services not running:"
echo "   systemctl start slipstream-client dns-pool-manager"
echo ""
echo "2. pool-all.txt empty:"
echo "   Upload your DNS resolver list to:"
echo "   /etc/slipstream/dns-pool/pool-all.txt"
echo ""
echo "3. Low bandwidth:"
echo "   - Check active resolver count"
echo "   - Wait for rotation to find better resolvers"
echo "   - Increase active_pool_size in config"
echo ""
echo "4. View detailed logs:"
echo "   journalctl -fu slipstream-client"
echo "   journalctl -fu dns-pool-manager"
echo ""
echo -e "${BLUE}═══════════════════════════════════════════════${NC}"
echo ""
