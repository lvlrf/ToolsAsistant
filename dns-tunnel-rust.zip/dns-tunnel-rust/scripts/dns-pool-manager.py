#!/usr/bin/env python3
"""
DNS Resolver Pool Manager
سیستم مدیریت هوشمند DNS resolver pool

ویژگی‌ها:
- Rotation هوشمند هر 1 ساعت
- Hot-reload بدون قطع ترافیک
- Weighted replacement
- Canary testing
- iperf3 auto-test و rollback
- Round-robin بدون تکرار

توسعه: DrConnect
"""

import os
import sys
import time
import json
import random
import subprocess
import argparse
import logging
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional, Tuple

# ==================== Configuration ====================

DEFAULT_CONFIG = {
    "pool_settings": {
        "active_pool_size": 100,
        "rotation_interval": 3600,
        "test_batch_size": 20,
        "max_rtt_threshold": 2000,
        "auto_replace_slow": True,
        "slow_threshold_rtt": 500,
        "max_rotation_time": 3000,
        "incremental_replace": True,
        "canary_testing": True,
        "canary_wait_time": 300
    },
    "test_server": {
        "domain": "test.t.irihost.com",
        "port": 5353,
        "timeout": 3,
        "query_prefix": "health-check"
    },
    "iperf3": {
        "server": "iperf.he.net",
        "port": 5201,
        "duration": 10,
        "auto_test_interval": 3600,
        "rollback_threshold": 0.7
    },
    "paths": {
        "pool_dir": "/etc/slipstream/dns-pool",
        "pool_all": "/etc/slipstream/dns-pool/pool-all.txt",
        "pool_active": "/etc/slipstream/dns-pool/pool-active.txt",
        "pool_used": "/etc/slipstream/dns-pool/pool-used.txt",
        "pool_failed": "/etc/slipstream/dns-pool/pool-failed.txt",
        "rotation_state": "/etc/slipstream/dns-pool/rotation-state.json",
        "stats_history": "/etc/slipstream/dns-pool/stats-history.json",
        "resolvers_file": "/etc/slipstream/resolvers.txt"
    },
    "logging": {
        "level": "INFO",
        "file": "/var/log/dns-pool-manager.log"
    }
}

# ==================== Logging Setup ====================

def setup_logging(config: dict):
    """تنظیم logging"""
    log_config = config.get("logging", {})
    level = getattr(logging, log_config.get("level", "INFO"))
    log_file = log_config.get("file", "/var/log/dns-pool-manager.log")
    
    logging.basicConfig(
        level=level,
        format='%(asctime)s [%(levelname)s] %(message)s',
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler(sys.stdout)
        ]
    )

# ==================== File Operations ====================

def load_file_lines(filepath: str) -> List[str]:
    """خواندن فایل به صورت لیست خطوط"""
    if not os.path.exists(filepath):
        return []
    with open(filepath, 'r') as f:
        return [line.strip() for line in f if line.strip()]

def save_file_lines(filepath: str, lines: List[str]):
    """ذخیره لیست به فایل"""
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, 'w') as f:
        for line in lines:
            f.write(f"{line}\n")

def load_json(filepath: str, default=None) -> dict:
    """خواندن JSON"""
    if not os.path.exists(filepath):
        return default if default is not None else {}
    try:
        with open(filepath, 'r') as f:
            return json.load(f)
    except:
        return default if default is not None else {}

def save_json(filepath: str, data: dict):
    """ذخیره JSON"""
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, 'w') as f:
        json.dump(data, f, indent=2)

# ==================== DNS Testing ====================

def test_dns_resolver(resolver_ip: str, domain: str, timeout: int = 3) -> Optional[Dict]:
    """
    تست یک DNS resolver
    
    Returns:
        {
            'success': bool,
            'rtt': int (ms),
            'resolver': str
        }
    """
    query_id = random.randint(10000, 99999)
    query_domain = f"test-{query_id}.{domain}"
    
    try:
        start_time = time.time()
        
        # استفاده از dig
        cmd = [
            'dig',
            f'@{resolver_ip}',
            query_domain,
            'TXT',
            '+short',
            f'+time={timeout}'
        ]
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout + 1
        )
        
        rtt = int((time.time() - start_time) * 1000)
        
        # بررسی موفقیت
        if result.returncode == 0:
            return {
                'success': True,
                'rtt': rtt,
                'resolver': resolver_ip
            }
    
    except subprocess.TimeoutExpired:
        logging.debug(f"Timeout testing {resolver_ip}")
    except Exception as e:
        logging.debug(f"Error testing {resolver_ip}: {e}")
    
    return {
        'success': False,
        'resolver': resolver_ip
    }

# ==================== iperf3 Testing ====================

def run_iperf3_test(server: str, port: int, duration: int = 10) -> Dict:
    """
    اجرای تست iperf3
    
    Returns:
        {
            'upload': float (Mbps),
            'download': float (Mbps),
            'success': bool
        }
    """
    try:
        # Upload test
        upload_cmd = ['iperf3', '-c', server, '-p', str(port), '-t', str(duration), '-J']
        upload_result = subprocess.run(upload_cmd, capture_output=True, text=True, timeout=duration + 10)
        upload_data = json.loads(upload_result.stdout)
        upload_mbps = upload_data['end']['sum_sent']['bits_per_second'] / 1_000_000
        
        time.sleep(2)
        
        # Download test
        download_cmd = ['iperf3', '-c', server, '-p', str(port), '-t', str(duration), '-R', '-J']
        download_result = subprocess.run(download_cmd, capture_output=True, text=True, timeout=duration + 10)
        download_data = json.loads(download_result.stdout)
        download_mbps = download_data['end']['sum_received']['bits_per_second'] / 1_000_000
        
        return {
            'upload': upload_mbps,
            'download': download_mbps,
            'success': True
        }
    
    except Exception as e:
        logging.error(f"iperf3 test failed: {e}")
        return {
            'upload': 0,
            'download': 0,
            'success': False
        }

# ==================== Resolver Selection ====================

def select_untested_batch(
    pool_all: List[str],
    pool_used: List[str],
    pool_failed: List[str],
    pool_active: List[str],
    batch_size: int
) -> List[str]:
    """
    انتخاب batch از IP های تست نشده
    
    استراتژی:
    1. فیلتر: حذف used, failed, active
    2. اگه خالی شد → reset used
    3. random sample
    """
    # فیلتر
    used_set = set(pool_used)
    failed_set = set(pool_failed)
    active_set = set(pool_active)
    
    available = [
        ip for ip in pool_all
        if ip not in used_set and ip not in failed_set and ip not in active_set
    ]
    
    # اگه همه تست شدن، reset
    if not available:
        logging.info("All IPs tested - Starting new round")
        available = [ip for ip in pool_all if ip not in failed_set and ip not in active_set]
        # Reset used
        return random.sample(available, min(batch_size, len(available))), True
    
    return random.sample(available, min(batch_size, len(available))), False

# ==================== Hot Reload ====================

def hot_reload_slipstream_client() -> bool:
    """
    تلاش برای hot-reload slipstream-client
    
    Returns:
        True اگه موفق شد
    """
    try:
        # روش 1: systemctl reload
        result = subprocess.run(
            ['systemctl', 'reload', 'slipstream-client'],
            capture_output=True,
            timeout=5
        )
        
        if result.returncode == 0:
            logging.info("Hot-reload successful (systemctl)")
            return True
        
        # روش 2: SIGHUP
        result = subprocess.run(
            ['killall', '-HUP', 'slipstream-client'],
            capture_output=True,
            timeout=5
        )
        
        if result.returncode == 0:
            logging.info("Hot-reload successful (SIGHUP)")
            time.sleep(2)
            return True
        
        logging.warning("Hot-reload not supported")
        return False
    
    except Exception as e:
        logging.error(f"Hot-reload failed: {e}")
        return False

def graceful_restart_slipstream_client() -> bool:
    """Restart بدون قطع ترافیک (fallback)"""
    try:
        logging.info("Performing graceful restart...")
        subprocess.run(['systemctl', 'restart', 'slipstream-client'], timeout=10)
        time.sleep(5)
        return True
    except Exception as e:
        logging.error(f"Graceful restart failed: {e}")
        return False

def apply_resolver_changes() -> bool:
    """اعمال تغییرات resolver"""
    # تلاش برای hot-reload
    if hot_reload_slipstream_client():
        return True
    
    # اگه نشد، graceful restart
    return graceful_restart_slipstream_client()

# ==================== Weighted Replacement ====================

def calculate_resolver_score(resolver: Dict) -> float:
    """
    محاسبه score یک resolver
    
    Score = (1000 - RTT) + bonus
    """
    rtt = resolver.get('rtt', 999)
    score = 1000 - min(rtt, 999)
    return score

def weighted_replacement(
    current_active: List[Dict],
    new_healthy: List[Dict],
    max_replace: int = 5
) -> Tuple[List[str], List[str]]:
    """
    جایگزینی weighted
    
    Returns:
        (IPs to add, IPs to remove)
    """
    # Sort active by score (کم‌ترین اول)
    active_sorted = sorted(current_active, key=calculate_resolver_score)
    
    # Sort new by score (بیشترین اول)  
    new_sorted = sorted(new_healthy, key=calculate_resolver_score, reverse=True)
    
    to_add = []
    to_remove = []
    
    # جایگزین تا max_replace
    for i in range(min(max_replace, len(new_sorted))):
        if i < len(active_sorted):
            # جایگزین کندترین با سریع‌ترین
            to_add.append(new_sorted[i]['resolver'])
            to_remove.append(active_sorted[i]['resolver'])
    
    return to_add, to_remove

# ==================== Canary Testing ====================

def canary_test(
    canary_ip: str,
    iperf_config: dict,
    baseline_speed: Dict,
    wait_time: int = 300
) -> bool:
    """
    تست canary
    
    1. اضافه کردن IP
    2. صبر wait_time ثانیه
    3. iperf3 test
    4. مقایسه با baseline
    
    Returns:
        True اگه canary موفق بود
    """
    logging.info(f"Starting canary test for {canary_ip}")
    
    # اضافه کردن (موقت)
    resolvers = load_file_lines('/etc/slipstream/dns-pool/pool-active.txt')
    resolvers.append(canary_ip)
    save_file_lines('/etc/slipstream/dns-pool/pool-active.txt', resolvers)
    
    # Update به slipstream
    save_file_lines('/etc/slipstream/resolvers.txt', resolvers)
    apply_resolver_changes()
    
    # صبر
    logging.info(f"Waiting {wait_time}s for canary to settle...")
    time.sleep(wait_time)
    
    # تست iperf3
    result = run_iperf3_test(
        iperf_config['server'],
        iperf_config['port'],
        iperf_config['duration']
    )
    
    if not result['success']:
        logging.warning("Canary test failed - iperf3 error")
        # Rollback
        resolvers.remove(canary_ip)
        save_file_lines('/etc/slipstream/dns-pool/pool-active.txt', resolvers)
        save_file_lines('/etc/slipstream/resolvers.txt', resolvers)
        apply_resolver_changes()
        return False
    
    # مقایسه
    threshold = iperf_config['rollback_threshold']
    baseline_avg = (baseline_speed['upload'] + baseline_speed['download']) / 2
    canary_avg = (result['upload'] + result['download']) / 2
    
    if canary_avg < baseline_avg * threshold:
        logging.warning(f"Canary failed - Speed dropped: {canary_avg:.1f} < {baseline_avg * threshold:.1f} Mbps")
        # Rollback
        resolvers.remove(canary_ip)
        save_file_lines('/etc/slipstream/dns-pool/pool-active.txt', resolvers)
        save_file_lines('/etc/slipstream/resolvers.txt', resolvers)
        apply_resolver_changes()
        return False
    
    logging.info(f"Canary passed - Speed: {canary_avg:.1f} Mbps (baseline: {baseline_avg:.1f})")
    return True

# ==================== Main Rotation ====================

def perform_rotation(config: dict):
    """اجرای یک دور rotation"""
    
    logging.info("="*60)
    logging.info("Starting rotation cycle")
    logging.info("="*60)
    
    start_time = time.time()
    paths = config['paths']
    pool_config = config['pool_settings']
    test_config = config['test_server']
    iperf_config = config['iperf3']
    
    # بارگذاری state
    pool_all = load_file_lines(paths['pool_all'])
    pool_active = load_file_lines(paths['pool_active'])
    pool_used = load_file_lines(paths['pool_used'])
    pool_failed = load_file_lines(paths['pool_failed'])
    
    if not pool_all:
        logging.error("pool-all.txt is empty! Please upload DNS resolver list")
        return
    
    logging.info(f"Pool state: All={len(pool_all)}, Active={len(pool_active)}, Used={len(pool_used)}, Failed={len(pool_failed)}")
    
    # انتخاب batch
    batch, reset_round = select_untested_batch(
        pool_all,
        pool_used,
        pool_failed,
        pool_active,
        pool_config['test_batch_size']
    )
    
    if reset_round:
        pool_used = []
    
    logging.info(f"Testing {len(batch)} resolvers...")
    
    # تست batch
    healthy_results = []
    failed_count = 0
    
    for ip in batch:
        # چک time budget
        elapsed = time.time() - start_time
        if elapsed > pool_config['max_rotation_time']:
            logging.warning(f"Reached time budget ({pool_config['max_rotation_time']}s)")
            break
        
        result = test_dns_resolver(ip, test_config['domain'], test_config['timeout'])
        
        if result['success'] and result['rtt'] < pool_config['max_rtt_threshold']:
            logging.info(f"  ✓ {ip} - RTT: {result['rtt']}ms")
            healthy_results.append(result)
        else:
            logging.info(f"  ✗ {ip} - Failed")
            pool_failed.append(ip)
            failed_count += 1
        
        pool_used.append(ip)
    
    logging.info(f"Test results: Healthy={len(healthy_results)}, Failed={failed_count}")
    
    # اگه نتیجه نداریم، skip
    if not healthy_results:
        logging.warning("No healthy resolvers found in this batch")
        save_file_lines(paths['pool_used'], pool_used)
        save_file_lines(paths['pool_failed'], pool_failed)
        return
    
    # Canary testing
    if pool_config['canary_testing'] and healthy_results:
        logging.info("Starting canary test...")
        
        # Baseline iperf3
        baseline = run_iperf3_test(
            iperf_config['server'],
            iperf_config['port'],
            iperf_config['duration']
        )
        
        if baseline['success']:
            canary_ip = healthy_results[0]['resolver']
            canary_passed = canary_test(
                canary_ip,
                iperf_config,
                baseline,
                pool_config['canary_wait_time']
            )
            
            if not canary_passed:
                logging.warning("Canary failed - Skipping batch replacement")
                healthy_results = []  # Skip replacement
        else:
            logging.warning("Baseline iperf3 failed - Skipping canary test")
    
    # Weighted replacement
    if healthy_results and pool_active:
        # بارگذاری active با stats
        active_with_stats = []
        stats = load_json(paths['stats_history'])
        
        for ip in pool_active:
            ip_stats = stats.get(ip, {'rtt': 999})
            active_with_stats.append({
                'resolver': ip,
                'rtt': ip_stats.get('rtt', 999)
            })
        
        # محاسبه replacement
        max_replace = 5 if pool_config['incremental_replace'] else len(healthy_results)
        to_add, to_remove = weighted_replacement(active_with_stats, healthy_results, max_replace)
        
        logging.info(f"Replacing {len(to_add)} resolvers...")
        
        # اعمال
        for add_ip, remove_ip in zip(to_add, to_remove):
            pool_active.remove(remove_ip)
            pool_active.append(add_ip)
            logging.info(f"  Replaced: {remove_ip} → {add_ip}")
        
        # ذخیره
        save_file_lines(paths['pool_active'], pool_active)
        save_file_lines(paths['resolvers_file'], pool_active)
        
        # آپدیت stats
        for result in healthy_results:
            stats[result['resolver']] = {
                'rtt': result['rtt'],
                'last_tested': datetime.now().isoformat(),
                'success': True
            }
        save_json(paths['stats_history'], stats)
        
        # Apply changes
        if apply_resolver_changes():
            logging.info("Resolver changes applied successfully")
        else:
            logging.error("Failed to apply resolver changes")
    
    elif not pool_active:
        # اولین بار - initialize active pool
        logging.info("Initializing active pool...")
        sorted_healthy = sorted(healthy_results, key=lambda x: x['rtt'])
        initial_active = [r['resolver'] for r in sorted_healthy[:pool_config['active_pool_size']]]
        
        save_file_lines(paths['pool_active'], initial_active)
        save_file_lines(paths['resolvers_file'], initial_active)
        apply_resolver_changes()
        
        logging.info(f"Initialized {len(initial_active)} active resolvers")
    
    # ذخیره state
    save_file_lines(paths['pool_used'], pool_used)
    save_file_lines(paths['pool_failed'], pool_failed)
    
    # ذخیره rotation state
    rotation_state = {
        'last_rotation': datetime.now().isoformat(),
        'duration': time.time() - start_time,
        'tested': len(batch),
        'healthy': len(healthy_results),
        'failed': failed_count,
        'active_count': len(pool_active)
    }
    save_json(paths['rotation_state'], rotation_state)
    
    elapsed = time.time() - start_time
    logging.info(f"Rotation completed in {elapsed:.1f}s")
    logging.info("="*60)

# ==================== Main Loop ====================

def main_loop(config: dict):
    """حلقه اصلی"""
    
    logging.info("DNS Pool Manager started")
    logging.info(f"Rotation interval: {config['pool_settings']['rotation_interval']}s")
    logging.info(f"Active pool size: {config['pool_settings']['active_pool_size']}")
    
    while True:
        try:
            perform_rotation(config)
            
            interval = config['pool_settings']['rotation_interval']
            logging.info(f"Next rotation in {interval}s ({interval//60} minutes)")
            time.sleep(interval)
        
        except KeyboardInterrupt:
            logging.info("Interrupted by user")
            break
        except Exception as e:
            logging.error(f"Error in main loop: {e}", exc_info=True)
            time.sleep(60)

# ==================== Entry Point ====================

def main():
    parser = argparse.ArgumentParser(description='DNS Resolver Pool Manager')
    parser.add_argument('--config', default='/etc/slipstream/pool-config.json', help='Config file path')
    args = parser.parse_args()
    
    # بارگذاری config
    config = load_json(args.config, DEFAULT_CONFIG)
    
    # Merge با default
    for key in DEFAULT_CONFIG:
        if key not in config:
            config[key] = DEFAULT_CONFIG[key]
    
    # Setup logging
    setup_logging(config)
    
    # Run
    main_loop(config)

if __name__ == "__main__":
    main()
