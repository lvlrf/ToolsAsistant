#!/bin/bash

# monitor.sh
# Real-time monitoring dashboard
# توسعه: DrConnect

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'

# Function to get service status
get_service_status() {
    if systemctl is-active --quiet $1; then
        echo -e "${GREEN}●${NC} Running"
    else
        echo -e "${RED}○${NC} Stopped"
    fi
}

# Function to get pool stats
get_pool_stats() {
    if [ -f "/etc/slipstream/dns-pool/rotation-state.json" ]; then
        cat /etc/slipstream/dns-pool/rotation-state.json 2>/dev/null || echo "{}"
    else
        echo "{}"
    fi
}

# Main loop
while true; do
    clear
    
    echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}           DNS Tunnel - Real-time Monitor${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
    echo ""
    
    # Service Status
    echo -e "${GREEN}Service Status:${NC}"
    echo "──────────────────────────────────────────────────────"
    printf "  slipstream-client     %s\n" "$(get_service_status slipstream-client)"
    printf "  dns-pool-manager      %s\n" "$(get_service_status dns-pool-manager)"
    printf "  backhaul-server       %s\n" "$(get_service_status backhaul-server 2>/dev/null || echo -e '${YELLOW}○${NC} Not installed')"
    echo ""
    
    # Pool Statistics
    echo -e "${GREEN}DNS Resolver Pool:${NC}"
    echo "──────────────────────────────────────────────────────"
    
    POOL_ALL=$(wc -l < /etc/slipstream/dns-pool/pool-all.txt 2>/dev/null || echo "0")
    POOL_ACTIVE=$(wc -l < /etc/slipstream/dns-pool/pool-active.txt 2>/dev/null || echo "0")
    POOL_USED=$(wc -l < /etc/slipstream/dns-pool/pool-used.txt 2>/dev/null || echo "0")
    POOL_FAILED=$(wc -l < /etc/slipstream/dns-pool/pool-failed.txt 2>/dev/null || echo "0")
    
    printf "  Total Pool:           %d IPs\n" $POOL_ALL
    printf "  Active Now:           %d IPs\n" $POOL_ACTIVE
    printf "  Used (Round):         %d IPs\n" $POOL_USED
    printf "  Failed:               %d IPs\n" $POOL_FAILED
    
    # Rotation info
    ROTATION_STATE=$(get_pool_stats)
    LAST_ROTATION=$(echo "$ROTATION_STATE" | jq -r '.last_rotation // "Never"' 2>/dev/null || echo "Never")
    
    if [ "$LAST_ROTATION" != "Never" ]; then
        LAST_TIME=$(date -d "$LAST_ROTATION" '+%H:%M:%S' 2>/dev/null || echo "Unknown")
        printf "  Last Rotation:        %s\n" "$LAST_TIME"
    fi
    echo ""
    
    # Traffic Statistics
    echo -e "${GREEN}Traffic Statistics:${NC}"
    echo "──────────────────────────────────────────────────────"
    
    # Get interface stats (tun0 or eth0)
    if [ -d "/sys/class/net/tun0" ]; then
        IFACE="tun0"
    else
        IFACE=$(ip route | grep default | awk '{print $5}' | head -1)
    fi
    
    RX_BYTES=$(cat /sys/class/net/$IFACE/statistics/rx_bytes 2>/dev/null || echo "0")
    TX_BYTES=$(cat /sys/class/net/$IFACE/statistics/tx_bytes 2>/dev/null || echo "0")
    
    RX_MB=$(awk "BEGIN {printf \"%.2f\", $RX_BYTES / 1048576}")
    TX_MB=$(awk "BEGIN {printf \"%.2f\", $TX_BYTES / 1048576}")
    
    printf "  Interface:            %s\n" "$IFACE"
    printf "  Download (total):     %s MB\n" "$RX_MB"
    printf "  Upload (total):       %s MB\n" "$TX_MB"
    echo ""
    
    # Bandwidth Prediction
    echo -e "${GREEN}Bandwidth Prediction:${NC}"
    echo "──────────────────────────────────────────────────────"
    
    PREDICTED=$(awk "BEGIN {print $POOL_ACTIVE * 5}")
    printf "  Expected Speed:       ~%d Mbps\n" $PREDICTED
    printf "  Formula:              %d resolvers × 5 Mbps\n" $POOL_ACTIVE
    echo ""
    
    # Connections
    echo -e "${GREEN}Active Connections:${NC}"
    echo "──────────────────────────────────────────────────────"
    
    SLIPSTREAM_CONN=$(ss -tn | grep -c :8080 2>/dev/null || echo "0")
    printf "  slipstream-client:    %d connections\n" $SLIPSTREAM_CONN
    echo ""
    
    # System Resources
    echo -e "${GREEN}System Resources:${NC}"
    echo "──────────────────────────────────────────────────────"
    
    CPU_USAGE=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1)
    MEM_USAGE=$(free | grep Mem | awk '{printf "%.1f", $3/$2 * 100}')
    
    printf "  CPU Usage:            %.1f%%\n" $CPU_USAGE
    printf "  Memory Usage:         %.1f%%\n" $MEM_USAGE
    echo ""
    
    # Recent Logs
    echo -e "${GREEN}Recent Logs (dns-pool-manager):${NC}"
    echo "──────────────────────────────────────────────────────"
    journalctl -u dns-pool-manager -n 3 --no-pager 2>/dev/null | tail -3
    echo ""
    
    echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
    echo "  Press Ctrl+C to exit | Refreshing every 2 seconds"
    echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
    
    sleep 2
done
