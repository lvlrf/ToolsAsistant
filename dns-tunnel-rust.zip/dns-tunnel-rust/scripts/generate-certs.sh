#!/bin/bash

# generate-certs.sh
# ساخت TLS certificates برای slipstream-rust
# توسعه: DrConnect

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}═══════════════════════════════════════${NC}"
echo -e "${GREEN}  TLS Certificate Generator${NC}"
echo -e "${GREEN}═══════════════════════════════════════${NC}"
echo ""

# Input
read -p "Enter domain (e.g., t.irihost.com): " DOMAIN
read -p "Certificate path [/etc/slipstream]: " CERT_PATH
CERT_PATH=${CERT_PATH:-/etc/slipstream}

mkdir -p "$CERT_PATH"

# Generate
echo ""
echo -e "${YELLOW}[INFO]${NC} Generating self-signed certificate..."

openssl req -x509 -newkey rsa:2048 -nodes \
    -keyout "$CERT_PATH/key.pem" \
    -out "$CERT_PATH/cert.pem" \
    -days 365 \
    -subj "/CN=$DOMAIN"

chmod 600 "$CERT_PATH/key.pem"
chmod 644 "$CERT_PATH/cert.pem"

echo ""
echo -e "${GREEN}[OK]${NC} Certificate generated successfully!"
echo ""
echo "Location:"
echo "  Certificate: $CERT_PATH/cert.pem"
echo "  Private Key: $CERT_PATH/key.pem"
echo ""
echo "Domain: $DOMAIN"
echo "Valid for: 365 days"
echo ""
echo -e "${YELLOW}[NOTE]${NC} This is a self-signed certificate for testing/tunneling only."
echo ""
