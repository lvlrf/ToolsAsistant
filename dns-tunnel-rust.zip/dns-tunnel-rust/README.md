# 🚀 DNS Tunnel Infrastructure با slipstream-rust

> **High-Performance DNS Tunneling** با سرعت ~800 Mbps - 1 Gbps  
> توسعه: DrConnect (@drconnect)

---

## 📊 مشخصات

- **Tunnel Protocol:** slipstream-rust (Authoritative Mode)
- **Expected Speed:** 800 Mbps - 1 Gbps (با 500 resolver)
- **Architecture:** DNS Tunnel + Backhaul + Smart Resolver Pool
- **Dashboard:** Dr.DNSttFucked (Web-based Management)

---

## 🏗️ معماری

```
[کاربران]
    ↓
[Backhaul Server - Iran] :1080
    ↓
[slipstream-client] :8080
    ↓ DNS queries از 100 resolver فعال
[500 DNS Resolvers - Pool Management]
    ↓
[slipstream-server - Foreign] :53
    ↓
[Backhaul Client] :5000
    ↓
[Internet]
```

---

## ⚡ ویژگی‌های کلیدی

### 🔄 Smart Resolver Pool Manager
- ✅ Rotation هوشمند هر 1 ساعت
- ✅ Hot-reload بدون قطع ترافیک
- ✅ Weighted replacement (بهترین‌ها می‌مونن)
- ✅ Auto-rollback با iperf3 testing
- ✅ Canary testing قبل از batch replace

### 📊 Dashboard: Dr.DNSttFucked
- ✅ Real-time traffic monitoring
- ✅ Bandwidth prediction
- ✅ iperf3 integration (auto-test)
- ✅ Service management (restart/status)
- ✅ Pool statistics
- ✅ Settings editor

### 🚀 Performance
- **slipstream-rust:** 2-3x سریعتر از C version
- **Authoritative Mode:** بدون upstream forwarding
- **BBR Congestion Control:** بهینه برای high-latency
- **Multi-resolver:** load balancing روی 100 DNS

---

## 📁 ساختار فایل‌ها

```
dns-tunnel-rust/
├── README.md                          # این فایل
├── configs/                           # تنظیمات
│   ├── pool-config.json              # تنظیمات pool manager
│   ├── slipstream-server.service     # Systemd سرور خارج
│   ├── slipstream-client.service     # Systemd سرور ایران
│   ├── dns-pool-manager.service      # Systemd pool manager
│   ├── backhaul-server.service       # Template Backhaul (Iran)
│   ├── backhaul-client.service       # Template Backhaul (Foreign)
│   └── 99-tunnel-tuning.conf         # Kernel optimization
│
├── scripts/                           # اسکریپت‌ها
│   ├── install-server.sh             # نصب سرور خارج
│   ├── install-client.sh             # نصب سرور ایران
│   ├── generate-certs.sh             # ساخت TLS cert
│   ├── dns-pool-manager.py           # Pool manager اصلی
│   ├── iperf3-auto-test.sh           # تست خودکار bandwidth
│   ├── setup-dns.sh                  # راهنمای DNS setup
│   ├── monitor.sh                    # مانیتورینگ real-time
│   └── troubleshoot.sh               # عیب‌یابی خودکار
│
├── dashboard/                         # Dashboard
│   ├── Dr.DNSttFucked.py             # Flask app
│   ├── templates/index.html          # صفحه اصلی
│   ├── static/                       # CSS/JS
│   └── setup-dashboard.sh            # نصب dashboard
│
├── docs/                              # مستندات
│   ├── DNS-SETUP.md                  # راهنمای DNS
│   ├── ARCHITECTURE.md               # معماری کامل
│   ├── BACKHAUL-INTEGRATION.md       # راهنمای Backhaul
│   └── TROUBLESHOOTING.md            # عیب‌یابی
│
└── downloads/                         # آفلاین
    └── offline-packages.txt          # لیست packages
```

---

## 🚀 نصب سریع

### سرور خارج (Foreign Server):

```bash
# 1. آپلود فایل‌ها
scp -r dns-tunnel-rust root@FOREIGN_IP:/root/

# 2. اجرای اسکریپت نصب
ssh root@FOREIGN_IP
cd /root/dns-tunnel-rust
chmod +x scripts/*.sh
./scripts/install-server.sh

# 3. تنظیم DNS
./scripts/setup-dns.sh
```

### سرور ایران (Iran Server):

```bash
# 1. آپلود فایل‌ها
scp -r dns-tunnel-rust root@IRAN_IP:/root/

# 2. آپلود لیست DNS resolvers
scp pool-all.txt root@IRAN_IP:/etc/slipstream/dns-pool/pool-all.txt

# 3. اجرای اسکریپت نصب
ssh root@IRAN_IP
cd /root/dns-tunnel-rust
chmod +x scripts/*.sh
./scripts/install-client.sh

# 4. نصب Dashboard
./dashboard/setup-dashboard.sh
```

---

## 📋 Checklist نصب

### قبل از نصب:

- [ ] یک domain داری (مثل irihost.com)
- [ ] دو سرور: یکی خارج، یکی ایران
- [ ] لیست DNS resolvers (از Shodan/FOFA)
- [ ] Backhaul setup (اختیاری)

### سرور خارج:

- [ ] نصب slipstream-rust
- [ ] Generate TLS cert/key
- [ ] تنظیم DNS: NS record
- [ ] باز کردن port UDP 53
- [ ] شروع slipstream-server
- [ ] نصب Backhaul Client (اگه استفاده میکنی)

### سرور ایران:

- [ ] نصب slipstream-rust
- [ ] آپلود pool-all.txt
- [ ] شروع dns-pool-manager
- [ ] شروع slipstream-client
- [ ] نصب Dashboard
- [ ] نصب Backhaul Server
- [ ] تست با iperf3

---

## 🔧 تنظیمات اولیه

### 1. Pool Config (`configs/pool-config.json`):

```json
{
  "pool_settings": {
    "active_pool_size": 100,        # تعداد DNS های فعال
    "rotation_interval": 3600,      # rotation هر 1 ساعت
    "test_batch_size": 20,          # تعداد تست در هر دور
    "max_rtt_threshold": 2000       # حداکثر RTT مجاز (ms)
  }
}
```

### 2. Domain Setup:

```
Domain: irihost.com
Tunnel: t.irihost.com
Test: test.t.irihost.com

DNS Records:
- A:  ns1.irihost.com → FOREIGN_SERVER_IP
- NS: t.irihost.com → ns1.irihost.com
- NS: test.t.irihost.com → ns1.irihost.com
```

### 3. Backhaul Setup (اختیاری):

**سرور ایران:**
```bash
backhaul -c config.json
# Remote: 127.0.0.1:8080 (slipstream-client)
# Local: 0.0.0.0:1080 (برای کاربران)
```

**سرور خارج:**
```bash
backhaul -c config.json
# Bind: 127.0.0.1:5000 (slipstream-server forward)
```

---

## 📊 Dashboard: Dr.DNSttFucked

دسترسی: `https://IRAN_SERVER_IP:8443`

**ویژگی‌ها:**
- 📈 Real-time traffic (upload/download/total)
- 🧮 Bandwidth prediction (active × 5 Mbps)
- 🔬 iperf3 auto-test
- 🔄 Service management
- ⚙️ Settings editor
- 📊 Pool statistics

**Authentication:**
- Username: admin
- Password: [در زمان نصب تولید می‌شود]

---

## 🧪 تست و بررسی

### تست سرعت دستی:

```bash
# Upload test
iperf3 -c iperf.he.net -p 5201 -t 10

# Download test  
iperf3 -c iperf.he.net -p 5201 -t 10 -R
```

### مانیتورینگ:

```bash
# Real-time monitoring
./scripts/monitor.sh

# Check pool status
cat /etc/slipstream/dns-pool/stats.json

# Check logs
journalctl -fu slipstream-client
journalctl -fu dns-pool-manager
```

---

## 🔍 عیب‌یابی

### اسکریپت خودکار:

```bash
./scripts/troubleshoot.sh
```

### مشکلات متداول:

**1. slipstream-client شروع نمیشه:**
```bash
# بررسی logs
journalctl -eu slipstream-client

# بررسی binary
which slipstream-client

# بررسی config
cat /etc/slipstream/resolvers.txt
```

**2. DNS resolve نمیشه:**
```bash
# تست DNS
dig @8.8.8.8 test.t.irihost.com

# بررسی propagation
./scripts/setup-dns.sh
```

**3. سرعت پایین:**
```bash
# بررسی تعداد active resolvers
wc -l /etc/slipstream/dns-pool/pool-active.txt

# اجرای rotation دستی
systemctl restart dns-pool-manager
```

مستندات کامل: `docs/TROUBLESHOOTING.md`

---

## 📈 انتظارات Performance

| تعداد DNS | سرعت تئوری | سرعت واقعی |
|-----------|------------|------------|
| 50        | ~250 Mbps  | ~200 Mbps  |
| 100       | ~500 Mbps  | ~400 Mbps  |
| 200       | ~1 Gbps    | ~800 Mbps  |
| 500       | ~2.5 Gbps  | ~1.5 Gbps  |

**فرمول:** `Active Resolvers × 5 Mbps = Expected Speed`

**Efficiency:** معمولاً 80-90%

---

## 🔐 امنیت

- ✅ TLS encryption (slipstream)
- ✅ Basic Auth (dashboard)
- ✅ Firewall rules
- ❌ **توجه:** این برای circumvention است، نه production security!

---

## 📝 نکات مهم

1. **لیست DNS resolvers:** باید خودت از Shodan/FOFA جمع‌آوری کنی
2. **Domain propagation:** 10-30 دقیقه طول می‌کشه
3. **Rotation time:** اولین rotation ممکنه 1 ساعت طول بکشه
4. **iperf3 testing:** برای سنجش دقیق همیشه iperf3 بزن
5. **Hot-reload:** بدون قطع ترافیک انجام میشه

---

## 🛠️ به‌روزرسانی

```bash
# Pull latest
cd /root/dns-tunnel-rust
git pull  # (اگه از git استفاده میکنی)

# یا دانلود manual و replace

# Restart services
systemctl restart slipstream-client
systemctl restart dns-pool-manager
systemctl restart dashboard
```

---

## 📞 پشتیبانی

**Developer:** DrConnect  
**Telegram:** [@drconnect](https://t.me/drconnect) | [@lvlRF](https://t.me/lvlRF)  
**Phone:** +98 912 741 9412

---

## 📜 License

این پروژه برای استفاده شخصی و آموزشی است.

---

## 🙏 تشکر

- **slipstream-rust:** [Mygod/slipstream-rust](https://github.com/Mygod/slipstream-rust)
- **Backhaul:** [Musixal/Backhaul](https://github.com/Musixal/Backhaul)
- **Dr.CDN-Scanner:** DrConnect

---

**نسخه:** 1.0  
**تاریخ:** 2025-01-17
