# Architecture Documentation

## معماری کامل

### Flow Diagram:
```
[کاربران] 
    ↓
[Backhaul Server] :1080 (Iran)
    ↓
[slipstream-client] :8080 (Iran)
    ↓ DNS queries از 100 resolver
[500 DNS Resolvers Pool]
    ↓
[slipstream-server] :53 (Foreign)
    ↓
[Backhaul Client] :5000 (Foreign)
    ↓
[Internet]
```

### Components:

1. **DNS Pool Manager**
   - Rotation هوشمند
   - Health checking
   - Hot-reload

2. **slipstream-rust**
   - DNS tunneling
   - Authoritative mode
   - QUIC-based

3. **Backhaul** (اختیاری)
   - TCP tunneling
   - Multi-transport

4. **Dashboard**
   - Web management
   - Real-time stats
   - iperf3 testing
