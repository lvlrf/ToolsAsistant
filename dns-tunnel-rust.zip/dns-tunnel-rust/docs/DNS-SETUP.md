# DNS Setup Guide

## مراحل تنظیم DNS

### 1. آماده‌سازی
- یک domain داشته باشید (مثل irihost.com)
- IP سرور خارج خود را بدانید

### 2. اضافه کردن Record ها

#### A Record:
```
Type: A
Name: ns1
Value: YOUR_FOREIGN_SERVER_IP
TTL: 300
```

#### NS Record (تانل اصلی):
```
Type: NS
Name: t (یا هر نام دلخواه)
Value: ns1.irihost.com
TTL: 300
```

#### NS Record (تست - اختیاری):
```
Type: NS
Name: test.t
Value: ns1.irihost.com
TTL: 300
```

### 3. تست Propagation

بعد از 10-30 دقیقه:
```bash
dig @8.8.8.8 ns1.irihost.com
dig @8.8.8.8 t.irihost.com NS
```

### نکات مهم
- Cloudflare: Proxy را خاموش کنید (Grey Cloud)
- چک کردن آنلاین: dnschecker.org
