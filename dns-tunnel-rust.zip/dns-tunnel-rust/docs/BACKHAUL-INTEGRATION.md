# Backhaul Integration Guide

## نصب Backhaul

### سرور خارج (Client):
```bash
wget https://github.com/Musixal/Backhaul/releases/latest/download/backhaul_linux_amd64.tar.gz
tar -xzf backhaul_linux_amd64.tar.gz
mv backhaul /usr/local/bin/
```

### Config (Foreign):
```toml
# /etc/backhaul/client-config.toml
[client]
remote_addr = "IRAN_IP:BACKHAUL_PORT"
transport = "tcp"
token = "YOUR_SECRET_TOKEN"

[client.tunnel]
address = "127.0.0.1:5000"
```

### سرور ایران (Server):
```toml
# /etc/backhaul/server-config.toml
[server]
bind_addr = "0.0.0.0:1080"
transport = "tcp"
token = "YOUR_SECRET_TOKEN"

[server.tunnel]
address = "127.0.0.1:8080"
```

### Integration Points:
- slipstream-server → Backhaul Client (127.0.0.1:5000)
- Backhaul Server → slipstream-client (127.0.0.1:8080)
- Users → Backhaul Server (0.0.0.0:1080)
