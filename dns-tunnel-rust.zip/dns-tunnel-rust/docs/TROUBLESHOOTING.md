# Troubleshooting Guide

## مشکلات متداول

### 1. slipstream-client شروع نمیشه
```bash
# چک logs
journalctl -eu slipstream-client

# بررسی pool-active.txt
cat /etc/slipstream/dns-pool/pool-active.txt

# restart
systemctl restart slipstream-client
```

### 2. DNS resolve نمیشه
```bash
# تست DNS
dig @8.8.8.8 t.irihost.com NS

# بررسی propagation
./scripts/setup-dns.sh
```

### 3. سرعت پایین
- بررسی تعداد active resolvers
- صبر برای rotation
- افزایش active_pool_size در config
- اجرای iperf3 test

### 4. Pool Manager کار نمیکنه
```bash
# چک logs
journalctl -eu dns-pool-manager

# بررسی pool-all.txt
wc -l /etc/slipstream/dns-pool/pool-all.txt

# restart
systemctl restart dns-pool-manager
```

### اسکریپت خودکار:
```bash
./scripts/troubleshoot.sh
```
