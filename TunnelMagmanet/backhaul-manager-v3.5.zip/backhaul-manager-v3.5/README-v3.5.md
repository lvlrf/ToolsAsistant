# Backhaul Configuration Generator v3.5

ابزار خودکار برای ساخت کانفیگ‌های Backhaul Tunnel با پشتیبانی از نسخه‌های Standard و Premium

برای راهنمای کامل، فایل‌های زیر را مطالعه کنید:
- QUICKSTART-v3.5.md - شروع سریع
- CHANGELOG-v3.5.md - تغییرات نسخه 3.5
- BINARY-PATHS.md - تنظیم مسیرها
- TUN-TRANSPORTS.md - راهنمای TUN
- WINDOWS-GUIDE.md - استفاده در ویندوز

نسخه: 3.5.0
تاریخ: 2026-01-03
