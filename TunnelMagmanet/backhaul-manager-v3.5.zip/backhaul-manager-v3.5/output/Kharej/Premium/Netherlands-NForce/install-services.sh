#!/bin/bash
# Backhaul PREMIUM - KHAREJ Server: Netherlands-NForce
# Generated: 2026-01-03 18:47:06

echo "Installing @lvlRF-Tunnel PREMIUM services for Netherlands-NForce..."
echo ""

# Extract binary from compressed file
echo "Extracting binary: @lvlRF-Tunnel.tar.gz"
cd /var/lib/@lvlRF-Tunnel/Premium
tar -xzf @lvlRF-Tunnel.tar.gz
chmod +x @lvlRF-Tunnel
echo ""


cat > /etc/systemd/system/@lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-tcp.service << 'EOF'
[Unit]
Description=Backhaul Kharej Doris-Respina <- Netherlands-NForce (TCP) Port 105
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Premium
ExecStart=/var/lib/@lvlRF-Tunnel/Premium/./@lvlRF-Tunnel -c config-Doris-Respina-tcp.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-tcpmux.service << 'EOF'
[Unit]
Description=Backhaul Kharej Doris-Respina <- Netherlands-NForce (TCPMUX) Port 106
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Premium
ExecStart=/var/lib/@lvlRF-Tunnel/Premium/./@lvlRF-Tunnel -c config-Doris-Respina-tcpmux.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-utcpmux.service << 'EOF'
[Unit]
Description=Backhaul Kharej Doris-Respina <- Netherlands-NForce (UTCPMUX) Port 107
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Premium
ExecStart=/var/lib/@lvlRF-Tunnel/Premium/./@lvlRF-Tunnel -c config-Doris-Respina-utcpmux.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-udp.service << 'EOF'
[Unit]
Description=Backhaul Kharej Doris-Respina <- Netherlands-NForce (UDP) Port 108
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Premium
ExecStart=/var/lib/@lvlRF-Tunnel/Premium/./@lvlRF-Tunnel -c config-Doris-Respina-udp.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-ws.service << 'EOF'
[Unit]
Description=Backhaul Kharej Doris-Respina <- Netherlands-NForce (WS) Port 109
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Premium
ExecStart=/var/lib/@lvlRF-Tunnel/Premium/./@lvlRF-Tunnel -c config-Doris-Respina-ws.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-wsmux.service << 'EOF'
[Unit]
Description=Backhaul Kharej Doris-Respina <- Netherlands-NForce (WSMUX) Port 110
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Premium
ExecStart=/var/lib/@lvlRF-Tunnel/Premium/./@lvlRF-Tunnel -c config-Doris-Respina-wsmux.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-uwsmux.service << 'EOF'
[Unit]
Description=Backhaul Kharej Doris-Respina <- Netherlands-NForce (UWSMUX) Port 111
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Premium
ExecStart=/var/lib/@lvlRF-Tunnel/Premium/./@lvlRF-Tunnel -c config-Doris-Respina-uwsmux.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-tcptun.service << 'EOF'
[Unit]
Description=Backhaul Kharej Doris-Respina <- Netherlands-NForce (TCPTUN) Port 112
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Premium
ExecStart=/var/lib/@lvlRF-Tunnel/Premium/./@lvlRF-Tunnel -c config-Doris-Respina-tcptun.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-faketcptun.service << 'EOF'
[Unit]
Description=Backhaul Kharej Doris-Respina <- Netherlands-NForce (FAKETCPTUN) Port 113
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Premium
ExecStart=/var/lib/@lvlRF-Tunnel/Premium/./@lvlRF-Tunnel -c config-Doris-Respina-faketcptun.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


# Reload systemd daemon
systemctl daemon-reload

# Enable and start @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-tcp
systemctl enable @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-tcp.service
systemctl start @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-tcp.service

# Enable and start @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-tcpmux
systemctl enable @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-tcpmux.service
systemctl start @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-tcpmux.service

# Enable and start @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-utcpmux
systemctl enable @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-utcpmux.service
systemctl start @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-utcpmux.service

# Enable and start @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-udp
systemctl enable @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-udp.service
systemctl start @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-udp.service

# Enable and start @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-ws
systemctl enable @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-ws.service
systemctl start @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-ws.service

# Enable and start @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-wsmux
systemctl enable @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-wsmux.service
systemctl start @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-wsmux.service

# Enable and start @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-uwsmux
systemctl enable @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-uwsmux.service
systemctl start @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-uwsmux.service

# Enable and start @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-tcptun
systemctl enable @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-tcptun.service
systemctl start @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-tcptun.service

# Enable and start @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-faketcptun
systemctl enable @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-faketcptun.service
systemctl start @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-faketcptun.service


echo "[OK] All services installed and started!"
echo ""
echo "Check status with:"
echo "  systemctl status @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-tcp"
echo "  systemctl status @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-tcpmux"
echo "  systemctl status @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-utcpmux"
echo "  systemctl status @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-udp"
echo "  systemctl status @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-ws"
echo "  systemctl status @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-wsmux"
echo "  systemctl status @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-uwsmux"
echo "  systemctl status @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-tcptun"
echo "  systemctl status @lvlRF-Tunnel-Premium-Netherlands-NForce-Doris-Respina-faketcptun"
