#!/bin/bash
# Backhaul STANDARD - KHAREJ Server: Netherlands-NForce
# Generated: 2026-01-03 18:47:06

echo "Installing @lvlRF-Tunnel STANDARD services for Netherlands-NForce..."
echo ""

# Extract binary from compressed file
echo "Extracting binary: @lvlRF-Tunnel.tar.gz"
cd /var/lib/@lvlRF-Tunnel/Standard
tar -xzf @lvlRF-Tunnel.tar.gz
chmod +x @lvlRF-Tunnel
echo ""


cat > /etc/systemd/system/@lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-tcp.service << 'EOF'
[Unit]
Description=Backhaul Kharej Doris-Respina <- Netherlands-NForce (TCP) Port 100
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Standard
ExecStart=/var/lib/@lvlRF-Tunnel/Standard/./@lvlRF-Tunnel -c config-Doris-Respina-tcp.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-tcpmux.service << 'EOF'
[Unit]
Description=Backhaul Kharej Doris-Respina <- Netherlands-NForce (TCPMUX) Port 101
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Standard
ExecStart=/var/lib/@lvlRF-Tunnel/Standard/./@lvlRF-Tunnel -c config-Doris-Respina-tcpmux.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-ws.service << 'EOF'
[Unit]
Description=Backhaul Kharej Doris-Respina <- Netherlands-NForce (WS) Port 102
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Standard
ExecStart=/var/lib/@lvlRF-Tunnel/Standard/./@lvlRF-Tunnel -c config-Doris-Respina-ws.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-wsmux.service << 'EOF'
[Unit]
Description=Backhaul Kharej Doris-Respina <- Netherlands-NForce (WSMUX) Port 103
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Standard
ExecStart=/var/lib/@lvlRF-Tunnel/Standard/./@lvlRF-Tunnel -c config-Doris-Respina-wsmux.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-udp.service << 'EOF'
[Unit]
Description=Backhaul Kharej Doris-Respina <- Netherlands-NForce (UDP) Port 104
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Standard
ExecStart=/var/lib/@lvlRF-Tunnel/Standard/./@lvlRF-Tunnel -c config-Doris-Respina-udp.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


# Reload systemd daemon
systemctl daemon-reload

# Enable and start @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-tcp
systemctl enable @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-tcp.service
systemctl start @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-tcp.service

# Enable and start @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-tcpmux
systemctl enable @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-tcpmux.service
systemctl start @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-tcpmux.service

# Enable and start @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-ws
systemctl enable @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-ws.service
systemctl start @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-ws.service

# Enable and start @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-wsmux
systemctl enable @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-wsmux.service
systemctl start @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-wsmux.service

# Enable and start @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-udp
systemctl enable @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-udp.service
systemctl start @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-udp.service


echo "[OK] All services installed and started!"
echo ""
echo "Check status with:"
echo "  systemctl status @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-tcp"
echo "  systemctl status @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-tcpmux"
echo "  systemctl status @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-ws"
echo "  systemctl status @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-wsmux"
echo "  systemctl status @lvlRF-Tunnel-Standard-Netherlands-NForce-Doris-Respina-udp"
