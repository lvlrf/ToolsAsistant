# Backhaul Port Mapping
Generated: 2026-01-03 18:47:06
Token: `b7cbe182cdab046c037ab7c212080db6`

---

## Port Assignments

| Version | Iran → Kharej | Transport | Tunnel Port | Web Port | iperf3 Port | TUN Subnet |
|---------|---------------|-----------|-------------|----------|-------------|------------|
| STANDARD | Doris-Respina → Netherlands-NForce | tcp       |         100 |      800 |        5001 | -          |
| STANDARD | Doris-Respina → Netherlands-NForce | tcpmux    |         101 |      801 |        5002 | -          |
| STANDARD | Doris-Respina → Netherlands-NForce | ws        |         102 |      802 |        5003 | -          |
| STANDARD | Doris-Respina → Netherlands-NForce | wsmux     |         103 |      803 |        5004 | -          |
| STANDARD | Doris-Respina → Netherlands-NForce | udp       |         104 |      804 |        5005 | -          |
| PREMIUM  | Doris-Respina → Netherlands-NForce | tcp       |         105 |      805 |        5006 | -          |
| PREMIUM  | Doris-Respina → Netherlands-NForce | tcpmux    |         106 |      806 |        5007 | -          |
| PREMIUM  | Doris-Respina → Netherlands-NForce | utcpmux   |         107 |      807 |        5008 | -          |
| PREMIUM  | Doris-Respina → Netherlands-NForce | udp       |         108 |      808 |        5009 | -          |
| PREMIUM  | Doris-Respina → Netherlands-NForce | ws        |         109 |      809 |        5010 | -          |
| PREMIUM  | Doris-Respina → Netherlands-NForce | wsmux     |         110 |      810 |        5011 | -          |
| PREMIUM  | Doris-Respina → Netherlands-NForce | uwsmux    |         111 |      811 |        5012 | -          |
| PREMIUM  | Doris-Respina → Netherlands-NForce | tcptun    |         112 |      812 |        5013 | 10.10.10.0/24 |
| PREMIUM  | Doris-Respina → Netherlands-NForce | faketcptun |         113 |      813 |        5014 | 10.10.20.0/24 |


---

## iperf3 Testing Guide

### On Kharej Servers:
Start iperf3 server on localhost:
```bash
iperf3 -s -B 127.0.0.1 -p 5201
```

### On Iran Servers:
Test each tunnel individually:
```bash
iperf3 -c 127.0.0.1 -p 5001 -t 10  # tcp to Netherlands-NForce
iperf3 -c 127.0.0.1 -p 5002 -t 10  # tcpmux to Netherlands-NForce
iperf3 -c 127.0.0.1 -p 5003 -t 10  # ws to Netherlands-NForce
iperf3 -c 127.0.0.1 -p 5004 -t 10  # wsmux to Netherlands-NForce
iperf3 -c 127.0.0.1 -p 5005 -t 10  # udp to Netherlands-NForce
iperf3 -c 127.0.0.1 -p 5006 -t 10  # tcp to Netherlands-NForce
iperf3 -c 127.0.0.1 -p 5007 -t 10  # tcpmux to Netherlands-NForce
iperf3 -c 127.0.0.1 -p 5008 -t 10  # utcpmux to Netherlands-NForce
iperf3 -c 127.0.0.1 -p 5009 -t 10  # udp to Netherlands-NForce
iperf3 -c 127.0.0.1 -p 5010 -t 10  # ws to Netherlands-NForce
iperf3 -c 127.0.0.1 -p 5011 -t 10  # wsmux to Netherlands-NForce
iperf3 -c 127.0.0.1 -p 5012 -t 10  # uwsmux to Netherlands-NForce
```

---

## Web Interface Access

Access the web sniffer interface at:

### Iran Servers:

**Doris-Respina** (`87.107.185.76`):
- tcp: http://87.107.185.76:800
- tcpmux: http://87.107.185.76:801
- ws: http://87.107.185.76:802
- wsmux: http://87.107.185.76:803
- udp: http://87.107.185.76:804
- tcp: http://87.107.185.76:805
- tcpmux: http://87.107.185.76:806
- utcpmux: http://87.107.185.76:807
- udp: http://87.107.185.76:808
- ws: http://87.107.185.76:809
- wsmux: http://87.107.185.76:810
- uwsmux: http://87.107.185.76:811
- tcptun: http://87.107.185.76:812
- faketcptun: http://87.107.185.76:813

### Kharej Servers:

**Netherlands-NForce** (`141.11.250.146`):
- tcp: http://141.11.250.146:800
- tcpmux: http://141.11.250.146:801
- ws: http://141.11.250.146:802
- wsmux: http://141.11.250.146:803
- udp: http://141.11.250.146:804
- tcp: http://141.11.250.146:805
- tcpmux: http://141.11.250.146:806
- utcpmux: http://141.11.250.146:807
- udp: http://141.11.250.146:808
- ws: http://141.11.250.146:809
- wsmux: http://141.11.250.146:810
- uwsmux: http://141.11.250.146:811
- tcptun: http://141.11.250.146:812
- faketcptun: http://141.11.250.146:813
