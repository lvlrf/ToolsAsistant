#!/bin/bash
# Backhaul PREMIUM - IRAN Server: Doris-Respina
# Generated: 2026-01-03 18:47:06

echo "Installing @lvlRF-Tunnel PREMIUM services for Doris-Respina..."
echo ""

# Extract binary from compressed file
echo "Extracting binary: @lvlRF-Tunnel.tar.gz"
cd /var/lib/@lvlRF-Tunnel/Premium
tar -xzf @lvlRF-Tunnel.tar.gz
chmod +x @lvlRF-Tunnel
echo ""


cat > /etc/systemd/system/@lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-tcp.service << 'EOF'
[Unit]
Description=Backhaul Iran Doris-Respina -> Netherlands-NForce (TCP) Port 105
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Premium
ExecStart=/var/lib/@lvlRF-Tunnel/Premium/./@lvlRF-Tunnel -c config-Netherlands-NForce-tcp.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-tcpmux.service << 'EOF'
[Unit]
Description=Backhaul Iran Doris-Respina -> Netherlands-NForce (TCPMUX) Port 106
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Premium
ExecStart=/var/lib/@lvlRF-Tunnel/Premium/./@lvlRF-Tunnel -c config-Netherlands-NForce-tcpmux.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-utcpmux.service << 'EOF'
[Unit]
Description=Backhaul Iran Doris-Respina -> Netherlands-NForce (UTCPMUX) Port 107
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Premium
ExecStart=/var/lib/@lvlRF-Tunnel/Premium/./@lvlRF-Tunnel -c config-Netherlands-NForce-utcpmux.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-udp.service << 'EOF'
[Unit]
Description=Backhaul Iran Doris-Respina -> Netherlands-NForce (UDP) Port 108
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Premium
ExecStart=/var/lib/@lvlRF-Tunnel/Premium/./@lvlRF-Tunnel -c config-Netherlands-NForce-udp.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-ws.service << 'EOF'
[Unit]
Description=Backhaul Iran Doris-Respina -> Netherlands-NForce (WS) Port 109
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Premium
ExecStart=/var/lib/@lvlRF-Tunnel/Premium/./@lvlRF-Tunnel -c config-Netherlands-NForce-ws.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-wsmux.service << 'EOF'
[Unit]
Description=Backhaul Iran Doris-Respina -> Netherlands-NForce (WSMUX) Port 110
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Premium
ExecStart=/var/lib/@lvlRF-Tunnel/Premium/./@lvlRF-Tunnel -c config-Netherlands-NForce-wsmux.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-uwsmux.service << 'EOF'
[Unit]
Description=Backhaul Iran Doris-Respina -> Netherlands-NForce (UWSMUX) Port 111
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Premium
ExecStart=/var/lib/@lvlRF-Tunnel/Premium/./@lvlRF-Tunnel -c config-Netherlands-NForce-uwsmux.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-tcptun.service << 'EOF'
[Unit]
Description=Backhaul Iran Doris-Respina -> Netherlands-NForce (TCPTUN) Port 112
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Premium
ExecStart=/var/lib/@lvlRF-Tunnel/Premium/./@lvlRF-Tunnel -c config-Netherlands-NForce-tcptun.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-faketcptun.service << 'EOF'
[Unit]
Description=Backhaul Iran Doris-Respina -> Netherlands-NForce (FAKETCPTUN) Port 113
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Premium
ExecStart=/var/lib/@lvlRF-Tunnel/Premium/./@lvlRF-Tunnel -c config-Netherlands-NForce-faketcptun.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


# Reload systemd daemon
systemctl daemon-reload

# Enable and start @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-tcp
systemctl enable @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-tcp.service
systemctl start @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-tcp.service

# Enable and start @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-tcpmux
systemctl enable @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-tcpmux.service
systemctl start @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-tcpmux.service

# Enable and start @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-utcpmux
systemctl enable @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-utcpmux.service
systemctl start @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-utcpmux.service

# Enable and start @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-udp
systemctl enable @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-udp.service
systemctl start @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-udp.service

# Enable and start @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-ws
systemctl enable @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-ws.service
systemctl start @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-ws.service

# Enable and start @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-wsmux
systemctl enable @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-wsmux.service
systemctl start @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-wsmux.service

# Enable and start @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-uwsmux
systemctl enable @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-uwsmux.service
systemctl start @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-uwsmux.service

# Enable and start @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-tcptun
systemctl enable @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-tcptun.service
systemctl start @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-tcptun.service

# Enable and start @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-faketcptun
systemctl enable @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-faketcptun.service
systemctl start @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-faketcptun.service


echo "[OK] All services installed and started!"
echo ""
echo "Check status with:"
echo "  systemctl status @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-tcp"
echo "  systemctl status @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-tcpmux"
echo "  systemctl status @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-utcpmux"
echo "  systemctl status @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-udp"
echo "  systemctl status @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-ws"
echo "  systemctl status @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-wsmux"
echo "  systemctl status @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-uwsmux"
echo "  systemctl status @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-tcptun"
echo "  systemctl status @lvlRF-Tunnel-Premium-Doris-Respina-Netherlands-NForce-faketcptun"
