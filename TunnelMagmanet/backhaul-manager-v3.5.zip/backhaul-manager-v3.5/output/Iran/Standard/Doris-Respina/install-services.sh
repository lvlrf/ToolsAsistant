#!/bin/bash
# Backhaul STANDARD - IRAN Server: Doris-Respina
# Generated: 2026-01-03 18:47:06

echo "Installing @lvlRF-Tunnel STANDARD services for Doris-Respina..."
echo ""

# Extract binary from compressed file
echo "Extracting binary: @lvlRF-Tunnel.tar.gz"
cd /var/lib/@lvlRF-Tunnel/Standard
tar -xzf @lvlRF-Tunnel.tar.gz
chmod +x @lvlRF-Tunnel
echo ""


cat > /etc/systemd/system/@lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-tcp.service << 'EOF'
[Unit]
Description=Backhaul Iran Doris-Respina -> Netherlands-NForce (TCP) Port 100
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Standard
ExecStart=/var/lib/@lvlRF-Tunnel/Standard/./@lvlRF-Tunnel -c config-Netherlands-NForce-tcp.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-tcpmux.service << 'EOF'
[Unit]
Description=Backhaul Iran Doris-Respina -> Netherlands-NForce (TCPMUX) Port 101
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Standard
ExecStart=/var/lib/@lvlRF-Tunnel/Standard/./@lvlRF-Tunnel -c config-Netherlands-NForce-tcpmux.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-ws.service << 'EOF'
[Unit]
Description=Backhaul Iran Doris-Respina -> Netherlands-NForce (WS) Port 102
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Standard
ExecStart=/var/lib/@lvlRF-Tunnel/Standard/./@lvlRF-Tunnel -c config-Netherlands-NForce-ws.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-wsmux.service << 'EOF'
[Unit]
Description=Backhaul Iran Doris-Respina -> Netherlands-NForce (WSMUX) Port 103
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Standard
ExecStart=/var/lib/@lvlRF-Tunnel/Standard/./@lvlRF-Tunnel -c config-Netherlands-NForce-wsmux.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/systemd/system/@lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-udp.service << 'EOF'
[Unit]
Description=Backhaul Iran Doris-Respina -> Netherlands-NForce (UDP) Port 104
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/lib/@lvlRF-Tunnel/Standard
ExecStart=/var/lib/@lvlRF-Tunnel/Standard/./@lvlRF-Tunnel -c config-Netherlands-NForce-udp.toml
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF


# Reload systemd daemon
systemctl daemon-reload

# Enable and start @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-tcp
systemctl enable @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-tcp.service
systemctl start @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-tcp.service

# Enable and start @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-tcpmux
systemctl enable @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-tcpmux.service
systemctl start @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-tcpmux.service

# Enable and start @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-ws
systemctl enable @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-ws.service
systemctl start @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-ws.service

# Enable and start @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-wsmux
systemctl enable @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-wsmux.service
systemctl start @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-wsmux.service

# Enable and start @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-udp
systemctl enable @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-udp.service
systemctl start @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-udp.service


echo "[OK] All services installed and started!"
echo ""
echo "Check status with:"
echo "  systemctl status @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-tcp"
echo "  systemctl status @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-tcpmux"
echo "  systemctl status @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-ws"
echo "  systemctl status @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-wsmux"
echo "  systemctl status @lvlRF-Tunnel-Standard-Doris-Respina-Netherlands-NForce-udp"
