# 🌐 Sub-Relay System

سیستم Relay برای Subscription Link مرزبان - دو مدل WireGuard و Xray با داشبورد مانیتورینگ

---

## 📖 فهرست مطالب

- [درباره پروژه](#درباره-پروژه)
- [معماری](#معماری)
- [پیش‌نیازها](#پیشنیازها)
- [نصب](#نصب)
- [تنظیمات](#تنظیمات)
- [راه‌اندازی](#راهاندازی)
- [مدیریت](#مدیریت)
- [عیب‌یابی](#عیبیابی)
- [سوالات متداول](#سوالات-متداول)

---

## 📝 درباره پروژه

این سیستم برای حل مشکل دسترسی مستقیم کاربران ایرانی به subscription link پنل مرزبان طراحی شده. به دلیل محدودیت‌های اینترانت، کاربران نمی‌توانند مستقیماً به سرور خارج متصل شوند. این سیستم یک relay روی سرور ایران ایجاد می‌کند که:

✅ کاربران به جای سرور خارج، به سرور ایران متصل می‌شوند  
✅ سرور ایران از طریق تانل (WireGuard یا Xray) به سرور خارج وصل می‌شود  
✅ درخواست‌های subscription از تانل عبور می‌کنند  
✅ سرویس فعلی شما همچنان کار می‌کند  

**ویژگی‌ها:**
- 🔀 دو مدل تانل: WireGuard (سریع‌تر) و Xray SOCKS5 (انعطاف‌پذیرتر)
- 🎛️ داشبورد وب برای مانیتورینگ و تغییر مدل
- 🔄 تغییر آسان بین دو مدل بدون نیاز به پیکربندی مجدد
- 🛡️ استفاده از HAProxy برای SNI routing
- 📊 مانیتورینگ زنده اتصالات و سرویس‌ها

---

## 🏗️ معماری

```
┌─────────────────┐
│   کاربر ایران   │
└────────┬────────┘
         │ :443
         ▼
    ┌─────────┐
    │ HAProxy │ ◄── SNI Routing
    └────┬────┘
         │
    ┌────┴──────────────────────┐
    │                           │
    ▼                           ▼
┌─────────┐              ┌──────────────┐
│ Tunnel  │              │ سرویس فعلی   │
│ Backend │              │ (پورت 8443)  │
└────┬────┘              └──────────────┘
     │
     │
┌────┴─────────────────┐
│  Mode A: WireGuard   │
│  → IP تانل           │
└──────────────────────┘
         یا
┌──────────────────────┐
│  Mode B: Xray        │
│  → Nginx → SOCKS5    │
└──────────────────────┘
         │
         ▼
    ┌─────────┐
    │  سرور   │
    │  خارج   │
    │ مرزبان  │
    └─────────┘
```

### توضیح جریان:

1. **کاربر** به `melodyurl.giftchi.link:443` متصل می‌شود
2. **HAProxy** بر اساس SNI تشخیص می‌دهد درخواست برای کدام سرویس است
3. اگر SNI برابر `melodyurl.giftchi.link` باشد → به تانل می‌فرستد
4. اگر SNI برابر `xray.giftchi.link` باشد → به سرویس فعلی می‌فرستد
5. **تانل** (WireGuard یا Xray) درخواست را به سرور خارج منتقل می‌کند

---

## 📋 پیش‌نیازها

### سرور ایران:
- Ubuntu 20.04+ / Debian 11+
- دسترسی root
- پورت‌های باز: 443، 8080
- حداقل 1 CPU، 1GB RAM

### سرور خارج (پنل مرزبان):
- WireGuard نصب شده (برای Mode A)
- یا یک کانکشن VLESS/VMess فعال (برای Mode B)
- دسترسی به پنل برای ساخت کانکشن

### دامنه:
- یک دامنه یا subdomain برای subscription (مثلاً `melodyurl.giftchi.link`)
- رکورد A که به IP سرور ایران اشاره کند
- گواهی SSL (از Let's Encrypt)

---

## 🚀 نصب

### 1️⃣ دانلود پروژه

```bash
# ایجاد پوشه و رفتن به آن
mkdir -p /opt/sub-relay
cd /opt/sub-relay

# کپی فایل‌های پروژه به اینجا
# (یا git clone اگر repository داری)
```

### 2️⃣ اجرای اسکریپت نصب

```bash
chmod +x install.sh
./install.sh
```

اسکریپت نصب این کارها را انجام می‌دهد:
- نصب پیش‌نیازها (HAProxy، Nginx، Python، WireGuard، Xray)
- ساخت محیط مجازی Python برای داشبورد
- ثبت سرویس‌های systemd
- آماده‌سازی فایل‌های کانفیگ

---

## ⚙️ تنظیمات

### 1️⃣ ویرایش فایل config.env

```bash
nano /opt/sub-relay/config.env
```

**تنظیمات ضروری که باید پر کنید:**

```bash
# مدل پیش‌فرض (wireguard یا xray)
ACTIVE_MODE="wireguard"

# دامنه subscription
SUB_DOMAIN="melodyurl.giftchi.link"

# آدرس پنل مرزبان
PANEL_URL="https://vdash.giftchi.link"

# SNI سرویس فعلی
EXISTING_SNI="xray.giftchi.link"
```

**برای مدل WireGuard:**

```bash
WG_SERVER_PUBLIC_KEY="YOUR_SERVER_PUBLIC_KEY"
WG_SERVER_ENDPOINT="SERVER_IP:51820"
WG_CLIENT_PRIVATE_KEY="YOUR_CLIENT_PRIVATE_KEY"
WG_CLIENT_IP="10.66.66.2/32"
WG_SERVER_IP="10.66.66.1"
```

**برای مدل Xray:**

```bash
XRAY_SERVER_ADDRESS="vdash.giftchi.link"
XRAY_SERVER_PORT="443"
XRAY_UUID="YOUR_UUID"
XRAY_WS_PATH="/ws"
XRAY_SNI="vdash.giftchi.link"
```

### 2️⃣ دریافت گواهی SSL

```bash
# نصب certbot (اگر نصب نیست)
apt install certbot -y

# دریافت گواهی
certbot certonly --standalone -d melodyurl.giftchi.link
```

**نکته:** قبل از این کار مطمئن شوید:
- رکورد DNS به IP سرور شما اشاره دارد
- پورت 80 باز است (certbot موقتاً استفاده می‌کند)

### 3️⃣ تنظیم تانل

#### برای WireGuard:

**روی سرور خارج:**

```bash
# نصب WireGuard
apt install wireguard -y

# تولید کلید سرور
wg genkey | tee server-private.key | wg pubkey > server-public.key

# مشاهده کلیدها
cat server-private.key  # این رو جایی امن نگه دار
cat server-public.key   # این رو در config.env سرور ایران قرار بده
```

**روی سرور ایران:**

```bash
# تولید کلید کلاینت
wg genkey | tee client-private.key | wg pubkey > client-public.key

# مشاهده کلیدها
cat client-private.key  # این رو در config.env قرار بده
cat client-public.key   # این رو به کانفیگ سرور خارج اضافه کن
```

**کانفیگ سرور خارج** (`/etc/wireguard/wg0.conf`):

```ini
[Interface]
PrivateKey = SERVER_PRIVATE_KEY
Address = 10.66.66.1/24
ListenPort = 51820
PostUp = sysctl -w net.ipv4.ip_forward=1
PostUp = iptables -A FORWARD -i wg0 -j ACCEPT
PostUp = iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE

[Peer]
PublicKey = CLIENT_PUBLIC_KEY
AllowedIPs = 10.66.66.2/32
PersistentKeepalive = 25
```

```bash
# فعال‌سازی WireGuard روی سرور خارج
systemctl enable wg-quick@wg0
systemctl start wg-quick@wg0

# باز کردن پورت
ufw allow 51820/udp
```

#### برای Xray:

1. در پنل مرزبان یک کانکشن VLESS/VMess بساز
2. اطلاعات کانکشن (UUID، SNI، Path) را در `config.env` قرار بده

---

## 🎬 راه‌اندازی

### 1️⃣ جابجایی سرویس فعلی

اگر سرویس Xray یا V2Ray شما روی پورت 443 است، ابتدا آن را به پورت 8443 منتقل کنید:

```bash
# ویرایش کانفیگ Xray
nano /usr/local/etc/xray/config.json

# پیدا کنید: "port": 443
# تغییر دهید به: "port": 8443

# ریستارت Xray
systemctl restart xray
```

### 2️⃣ فعال‌سازی یکی از مدل‌ها

```bash
# فعال‌سازی مدل WireGuard
/opt/sub-relay/switch-mode.sh wireguard

# یا فعال‌سازی مدل Xray
/opt/sub-relay/switch-mode.sh xray
```

### 3️⃣ بررسی وضعیت

```bash
# چک کردن سرویس‌ها
systemctl status haproxy
systemctl status sub-relay-dashboard

# برای WireGuard:
systemctl status wg-quick@wg0

# برای Xray:
systemctl status xray-client
systemctl status nginx
```

### 4️⃣ دسترسی به داشبورد

مرورگر را باز کنید و به این آدرس بروید:

```
http://YOUR_SERVER_IP:8080
```

---

## 🎛️ مدیریت

### تغییر بین دو مدل

```bash
# تغییر به WireGuard
/opt/sub-relay/switch-mode.sh wireguard

# تغییر به Xray
/opt/sub-relay/switch-mode.sh xray
```

یا از داشبورد وب روی دکمه‌های "تغییر به WireGuard" یا "تغییر به Xray" کلیک کنید.

### ریستارت سرویس‌ها

```bash
# ریستارت HAProxy
systemctl restart haproxy

# ریستارت داشبورد
systemctl restart sub-relay-dashboard

# ریستارت WireGuard
systemctl restart wg-quick@wg0

# ریستارت Xray
systemctl restart xray-client
```

### مشاهده لاگ‌ها

```bash
# لاگ HAProxy
journalctl -u haproxy -f

# لاگ داشبورد
journalctl -u sub-relay-dashboard -f

# لاگ WireGuard
journalctl -u wg-quick@wg0 -f

# لاگ Xray
journalctl -u xray-client -f
```

---

## 🔧 عیب‌یابی

### مشکل: تانل WireGuard متصل نمی‌شود

```bash
# بررسی وضعیت
wg show wg0

# چک کردن ping
ping 10.66.66.1

# بررسی فایروال سرور خارج
# مطمئن شوید پورت 51820/udp باز است
```

### مشکل: Xray SOCKS5 کار نمی‌کند

```bash
# تست SOCKS5
curl -x socks5://127.0.0.1:1080 https://www.google.com

# لاگ Xray
journalctl -u xray-client -n 50

# بررسی پورت
netstat -tlnp | grep 1080
```

### مشکل: HAProxy ترافیک را forward نمی‌کند

```bash
# لاگ HAProxy
tail -f /var/log/haproxy.log

# تست SNI
openssl s_client -connect 127.0.0.1:443 -servername melodyurl.giftchi.link

# چک کردن کانفیگ
haproxy -c -f /etc/haproxy/haproxy.cfg
```

### مشکل: داشبورد باز نمی‌شود

```bash
# بررسی وضعیت
systemctl status sub-relay-dashboard

# بررسی پورت
netstat -tlnp | grep 8080

# ریستارت
systemctl restart sub-relay-dashboard
```

---

## ❓ سوالات متداول

### آیا می‌توانم هر دو مدل را همزمان فعال کنم؟

خیر، در هر لحظه فقط یکی از دو مدل فعال است. برای تغییر از اسکریپت `switch-mode.sh` استفاده کنید.

### کدام مدل بهتر است؟

- **WireGuard:** سریع‌تر، کم‌حجم‌تر، مصرف CPU کمتر - توصیه می‌شود
- **Xray:** انعطاف‌پذیرتر، قابلیت obfuscation بیشتر

### چطور subscription link را به کاربران بدهم؟

به جای لینک پنل اصلی، این لینک را بدهید:

```
https://melodyurl.giftchi.link/sub/YOUR_TOKEN
```

### آیا می‌توانم چند دامنه داشته باشم؟

بله، در کانفیگ HAProxy می‌توانید چندین SNI اضافه کنید.

### چطور پورت داشبورد را تغییر دهم؟

در `config.env` مقدار `DASHBOARD_PORT` را تغییر دهید و سرویس را ریستارت کنید.

---

## 📞 پشتیبانی

- کانال تلگرام: [@drconnect](https://t.me/drconnect)
- پشتیبانی: `+98 912 741 9412`

---

## 📄 لایسنس

این پروژه تحت لایسنس MIT منتشر شده است.

---

**ساخته شده با ❤️ توسط DrConnect**
